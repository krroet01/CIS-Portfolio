﻿namespace Prog1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.totalsquarefeetLabel = new System.Windows.Forms.Label();
            this.paintdesiredLabel = new System.Windows.Forms.Label();
            this.gallonsofpaintLabel = new System.Windows.Forms.Label();
            this.hoursoflaborLabel = new System.Windows.Forms.Label();
            this.costofpaintLabel = new System.Windows.Forms.Label();
            this.costoflaborLabel = new System.Windows.Forms.Label();
            this.totalcostLabel = new System.Windows.Forms.Label();
            this.squarefeetTextBox = new System.Windows.Forms.TextBox();
            this.paintdesiredTextBox = new System.Windows.Forms.TextBox();
            this.gallonsofpaintOutputLabel = new System.Windows.Forms.Label();
            this.hoursoflaborOutputLabel = new System.Windows.Forms.Label();
            this.costofpaintOutputLabel = new System.Windows.Forms.Label();
            this.costoflaborOutputLabel = new System.Windows.Forms.Label();
            this.totalcostOutputLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.pricepergallonLabel = new System.Windows.Forms.Label();
            this.pricepergallonTextBox = new System.Windows.Forms.TextBox();
            this.squarefeetLabel = new System.Windows.Forms.Label();
            this.totalsquarefeetOutputLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // totalsquarefeetLabel
            // 
            this.totalsquarefeetLabel.AutoSize = true;
            this.totalsquarefeetLabel.Location = new System.Drawing.Point(287, 38);
            this.totalsquarefeetLabel.Name = "totalsquarefeetLabel";
            this.totalsquarefeetLabel.Size = new System.Drawing.Size(155, 13);
            this.totalsquarefeetLabel.TabIndex = 0;
            this.totalsquarefeetLabel.Text = "Total square feet to be painted:";
            // 
            // paintdesiredLabel
            // 
            this.paintdesiredLabel.AutoSize = true;
            this.paintdesiredLabel.Location = new System.Drawing.Point(28, 70);
            this.paintdesiredLabel.Name = "paintdesiredLabel";
            this.paintdesiredLabel.Size = new System.Drawing.Size(112, 13);
            this.paintdesiredLabel.TabIndex = 1;
            this.paintdesiredLabel.Text = "Coats of paint desired:";
            // 
            // gallonsofpaintLabel
            // 
            this.gallonsofpaintLabel.AutoSize = true;
            this.gallonsofpaintLabel.Location = new System.Drawing.Point(298, 70);
            this.gallonsofpaintLabel.Name = "gallonsofpaintLabel";
            this.gallonsofpaintLabel.Size = new System.Drawing.Size(144, 13);
            this.gallonsofpaintLabel.TabIndex = 2;
            this.gallonsofpaintLabel.Text = "# of gallons of paint required:";
            // 
            // hoursoflaborLabel
            // 
            this.hoursoflaborLabel.AutoSize = true;
            this.hoursoflaborLabel.Location = new System.Drawing.Point(325, 103);
            this.hoursoflaborLabel.Name = "hoursoflaborLabel";
            this.hoursoflaborLabel.Size = new System.Drawing.Size(117, 13);
            this.hoursoflaborLabel.TabIndex = 3;
            this.hoursoflaborLabel.Text = "Hours of labor required:";
            // 
            // costofpaintLabel
            // 
            this.costofpaintLabel.AutoSize = true;
            this.costofpaintLabel.Location = new System.Drawing.Point(355, 134);
            this.costofpaintLabel.Name = "costofpaintLabel";
            this.costofpaintLabel.Size = new System.Drawing.Size(87, 13);
            this.costofpaintLabel.TabIndex = 4;
            this.costofpaintLabel.Text = "Cost of the paint:";
            // 
            // costoflaborLabel
            // 
            this.costoflaborLabel.AutoSize = true;
            this.costoflaborLabel.Location = new System.Drawing.Point(355, 166);
            this.costoflaborLabel.Name = "costoflaborLabel";
            this.costoflaborLabel.Size = new System.Drawing.Size(87, 13);
            this.costoflaborLabel.TabIndex = 5;
            this.costoflaborLabel.Text = "Cost of the labor:";
            // 
            // totalcostLabel
            // 
            this.totalcostLabel.AutoSize = true;
            this.totalcostLabel.Location = new System.Drawing.Point(311, 219);
            this.totalcostLabel.Name = "totalcostLabel";
            this.totalcostLabel.Size = new System.Drawing.Size(131, 13);
            this.totalcostLabel.TabIndex = 6;
            this.totalcostLabel.Text = "Total Cost of the paint job:";
            // 
            // squarefeetTextBox
            // 
            this.squarefeetTextBox.Location = new System.Drawing.Point(146, 35);
            this.squarefeetTextBox.Name = "squarefeetTextBox";
            this.squarefeetTextBox.Size = new System.Drawing.Size(100, 20);
            this.squarefeetTextBox.TabIndex = 7;
            // 
            // paintdesiredTextBox
            // 
            this.paintdesiredTextBox.Location = new System.Drawing.Point(146, 67);
            this.paintdesiredTextBox.Name = "paintdesiredTextBox";
            this.paintdesiredTextBox.Size = new System.Drawing.Size(100, 20);
            this.paintdesiredTextBox.TabIndex = 8;
            // 
            // gallonsofpaintOutputLabel
            // 
            this.gallonsofpaintOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gallonsofpaintOutputLabel.Location = new System.Drawing.Point(448, 65);
            this.gallonsofpaintOutputLabel.Name = "gallonsofpaintOutputLabel";
            this.gallonsofpaintOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.gallonsofpaintOutputLabel.TabIndex = 9;
            this.gallonsofpaintOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // hoursoflaborOutputLabel
            // 
            this.hoursoflaborOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.hoursoflaborOutputLabel.Location = new System.Drawing.Point(448, 97);
            this.hoursoflaborOutputLabel.Name = "hoursoflaborOutputLabel";
            this.hoursoflaborOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.hoursoflaborOutputLabel.TabIndex = 10;
            this.hoursoflaborOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // costofpaintOutputLabel
            // 
            this.costofpaintOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.costofpaintOutputLabel.Location = new System.Drawing.Point(448, 129);
            this.costofpaintOutputLabel.Name = "costofpaintOutputLabel";
            this.costofpaintOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.costofpaintOutputLabel.TabIndex = 11;
            this.costofpaintOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // costoflaborOutputLabel
            // 
            this.costoflaborOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.costoflaborOutputLabel.Location = new System.Drawing.Point(448, 161);
            this.costoflaborOutputLabel.Name = "costoflaborOutputLabel";
            this.costoflaborOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.costoflaborOutputLabel.TabIndex = 12;
            this.costoflaborOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // totalcostOutputLabel
            // 
            this.totalcostOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalcostOutputLabel.Location = new System.Drawing.Point(448, 214);
            this.totalcostOutputLabel.Name = "totalcostOutputLabel";
            this.totalcostOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.totalcostOutputLabel.TabIndex = 13;
            this.totalcostOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(111, 180);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 10;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // pricepergallonLabel
            // 
            this.pricepergallonLabel.AutoSize = true;
            this.pricepergallonLabel.Location = new System.Drawing.Point(57, 103);
            this.pricepergallonLabel.Name = "pricepergallonLabel";
            this.pricepergallonLabel.Size = new System.Drawing.Size(83, 13);
            this.pricepergallonLabel.TabIndex = 15;
            this.pricepergallonLabel.Text = "Price per gallon:";
            // 
            // pricepergallonTextBox
            // 
            this.pricepergallonTextBox.Location = new System.Drawing.Point(146, 100);
            this.pricepergallonTextBox.Name = "pricepergallonTextBox";
            this.pricepergallonTextBox.Size = new System.Drawing.Size(100, 20);
            this.pricepergallonTextBox.TabIndex = 9;
            // 
            // squarefeetLabel
            // 
            this.squarefeetLabel.AutoSize = true;
            this.squarefeetLabel.Location = new System.Drawing.Point(55, 38);
            this.squarefeetLabel.Name = "squarefeetLabel";
            this.squarefeetLabel.Size = new System.Drawing.Size(85, 13);
            this.squarefeetLabel.TabIndex = 17;
            this.squarefeetLabel.Text = "# of square feet:";
            // 
            // totalsquarefeetOutputLabel
            // 
            this.totalsquarefeetOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalsquarefeetOutputLabel.Location = new System.Drawing.Point(448, 33);
            this.totalsquarefeetOutputLabel.Name = "totalsquarefeetOutputLabel";
            this.totalsquarefeetOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.totalsquarefeetOutputLabel.TabIndex = 18;
            this.totalsquarefeetOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(584, 261);
            this.Controls.Add(this.totalsquarefeetOutputLabel);
            this.Controls.Add(this.squarefeetLabel);
            this.Controls.Add(this.pricepergallonTextBox);
            this.Controls.Add(this.pricepergallonLabel);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.totalcostOutputLabel);
            this.Controls.Add(this.costoflaborOutputLabel);
            this.Controls.Add(this.costofpaintOutputLabel);
            this.Controls.Add(this.hoursoflaborOutputLabel);
            this.Controls.Add(this.gallonsofpaintOutputLabel);
            this.Controls.Add(this.paintdesiredTextBox);
            this.Controls.Add(this.squarefeetTextBox);
            this.Controls.Add(this.totalcostLabel);
            this.Controls.Add(this.costoflaborLabel);
            this.Controls.Add(this.costofpaintLabel);
            this.Controls.Add(this.hoursoflaborLabel);
            this.Controls.Add(this.gallonsofpaintLabel);
            this.Controls.Add(this.paintdesiredLabel);
            this.Controls.Add(this.totalsquarefeetLabel);
            this.Name = "Form1";
            this.Text = "Program1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label totalsquarefeetLabel;
        private System.Windows.Forms.Label paintdesiredLabel;
        private System.Windows.Forms.Label gallonsofpaintLabel;
        private System.Windows.Forms.Label hoursoflaborLabel;
        private System.Windows.Forms.Label costofpaintLabel;
        private System.Windows.Forms.Label costoflaborLabel;
        private System.Windows.Forms.Label totalcostLabel;
        private System.Windows.Forms.TextBox squarefeetTextBox;
        private System.Windows.Forms.TextBox paintdesiredTextBox;
        private System.Windows.Forms.Label gallonsofpaintOutputLabel;
        private System.Windows.Forms.Label hoursoflaborOutputLabel;
        private System.Windows.Forms.Label costofpaintOutputLabel;
        private System.Windows.Forms.Label costoflaborOutputLabel;
        private System.Windows.Forms.Label totalcostOutputLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label pricepergallonLabel;
        private System.Windows.Forms.TextBox pricepergallonTextBox;
        private System.Windows.Forms.Label squarefeetLabel;
        private System.Windows.Forms.Label totalsquarefeetOutputLabel;
    }
}

