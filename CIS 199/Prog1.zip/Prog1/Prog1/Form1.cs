﻿// Grading ID: B1403
// Program 1
// Due Date: September 27, 2016 at 11:59 PM
// CIS 199-75
// This application allows the user to input a number of square feet, the number of paint coats desired, and the price per 
// gallon of paint and calculate the amounts of work and costs required to complete the job. 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog1
{
    public partial class Form1 : Form
    {
        const double SQUAREFEETOFSPACE = 275;   // A constant rate of 275 square feet of wall space
        const double HOURSOFLABOR = 8;          // A constant rate of 8 labor hours for every 275 square feet painted
        const double COSTPERHOUR = 12.50;       // A constant rate of $12.50 charged per labor hour completed 

        public Form1()
        {
            InitializeComponent();
        }

        // Calculates the output values based on the information put in for the inputs
        private void calculateButton_Click(object sender, EventArgs e)
        {
            double squareFeet;          // Holds the project's original amount of square feet
            double paintDesired;        // Holds the amount of paint coats desired for the project
            double gallonPrice;         // Holds the price per paint gallon
            double totalSquareFeet;     // Holds the total amount of square feet to be painted for the project
            double paintRequiredToUse;  // Holds the amount of paint required to be used for this project
            double paintRequiredToBuy;  // Holds the amount of paint required to be bought for this project
            double laborHours;          // Holds the amount of labor hours the job requires
            double paintCost;           // Holds the value for the cost of paint
            double laborCost;           // Holds the value for the cost of labor
            double totalCost;           // Holds the total cost for the paint and labor

            // Gets the original input numbers
            squareFeet = double.Parse(squarefeetTextBox.Text);
            paintDesired = double.Parse(paintdesiredTextBox.Text);
            gallonPrice = double.Parse(pricepergallonTextBox.Text);

            // Calculates the total amounts of square feet, paint required for the job, labor hours, and costs
            totalSquareFeet = squareFeet * paintDesired;
            paintRequiredToUse = totalSquareFeet / SQUAREFEETOFSPACE;
            paintRequiredToBuy = Math.Ceiling(paintRequiredToUse);
            laborHours = paintRequiredToUse * HOURSOFLABOR;
            paintCost = gallonPrice * paintRequiredToBuy;
            laborCost = COSTPERHOUR * laborHours;
            totalCost = paintCost + laborCost;

            // Displays the results of the calculations
            totalsquarefeetOutputLabel.Text = totalSquareFeet.ToString("n1");
            gallonsofpaintOutputLabel.Text = paintRequiredToBuy.ToString("n0");
            hoursoflaborOutputLabel.Text = laborHours.ToString("n1");
            costofpaintOutputLabel.Text = paintCost.ToString("c");
            costoflaborOutputLabel.Text = laborCost.ToString("c");
            totalcostOutputLabel.Text = totalCost.ToString("c");
        }
    }
}
