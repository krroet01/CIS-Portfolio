﻿// Grading ID: B1403
// Program 4
// Due Date: Tuesday December 6, 2016 at 11:59 PM
// CIS 199-75
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog4
{
    public partial class MainForm : Form
    {
        private List<LibraryBook> bookList = new List<LibraryBook>();   // Create a list to hold the library book objects

        public MainForm()
        {
            InitializeComponent();
        }

        // Precondition: All textboxes must have entered text
        // Postcondition: The title of the book will show up in the listbox
        private void addButton_Click(object sender, EventArgs e)
        {
            string bookTitle;       // Variable to hold the title of the book
            string bookAuthor;      // Variable to hold the author of the book
            string bookPublisher;   // Variable to hold the publisher of the book
            int bookCopyrightYear;  // Variable to hold the copyright year of the book
            string bookCallNumber;  // Variable to hold the call number of the book
            LibraryBook myBook;     // Variable to hold the book's information

            // Check for empty textboxes
            if (titleTextBox.Text == "")
            {
                MessageBox.Show("Enter a title"); // Error message if title textbox is empty
            }
            else if (authorTextBox.Text == "")
            {
                MessageBox.Show("Enter an author"); // Error message if author textbox is empty
            }
            else if (publisherTextBox.Text == "")
            {
                MessageBox.Show("Enter a publisher"); // Error message if publisher textbox is empty
            }
            else if (callNumberTextBox.Text == "")
            {
                MessageBox.Show("Enter a call number"); // Error message if call number textbox is empty
            }
            else if (int.TryParse(copyrightYearTextBox.Text, out bookCopyrightYear) && bookCopyrightYear >= 0)
            {
                bookTitle = titleTextBox.Text;              // Get the book's title
                bookAuthor = authorTextBox.Text;            // Get the book's author
                bookPublisher = publisherTextBox.Text;      // Get the book's publisher
                bookCallNumber = callNumberTextBox.Text;    // Get the book's call number

                myBook = new LibraryBook(bookTitle, bookAuthor, bookPublisher, bookCopyrightYear, bookCallNumber); // Create a library book object
                bookList.Add(myBook);   // Add the library book object to the list
                bookListBox.Items.Add(myBook.Title);    // Add an entry to the list box
            }
            else
            {
                MessageBox.Show("Enter a valid year"); // Error message if year entered is invalid
            }
        }

        // Precondition: A book title in the listbox must be selected
        // Postcondition: The title, author, publisher, copyright year, call number, and checked out status will appear
        private void detailsButton_Click(object sender, EventArgs e)
        {
            int index = bookListBox.SelectedIndex;  // Get the index of the selected item

            if (index >= 0)
            {
                MessageBox.Show(bookList[index].ToString()); // Title, author, publisher, copyright year, call number, and checked out status appear
            }
            else
            {
                MessageBox.Show("Select a title from the list"); // Error message if nothing is selected in the listbox
            }
        }

        // Precondition: A book title in the listbox must be selected
        // Postcondition: The book will be checked out and the details will show true for the status
        private void checkOutButton_Click(object sender, EventArgs e)
        {
            int index = bookListBox.SelectedIndex;  // Get the index of the selected item

            if (index >= 0)
            {
                bookList[index].CheckOut(); // The book is checked out, and the checked out status shows true

                MessageBox.Show(bookList[index].Title + " has been checked out."); // Message box shows that book has been checked out
            }
            else
            {
                MessageBox.Show("Select a title from the list"); // Error message if nothing is selected in the listbox
            }
        }

        // Precondition: A book title in the listbox must be selected
        // Postcondition: The book will be returned to the shelf and the details will show false for the status
        private void returnButton_Click(object sender, EventArgs e)
        {
            int index = bookListBox.SelectedIndex; // Get the index of the selected item

            if (index >= 0)
            {
                bookList[index].ReturnToShelf();    // The book is returned to the shelf, and the checked out status shows false

                MessageBox.Show(bookList[index].Title + " has been returned to the shelf."); // Message box shows that book has been returned to shelf
            }
            else
            {
                MessageBox.Show("Select a title from the list"); // Error message if nothing is selected in the listbox
            }
        }
    }
}
