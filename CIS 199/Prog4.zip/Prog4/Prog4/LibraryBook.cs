﻿// Grading ID: 1403
// Program 4
// Due Date: Tuesday December 6, 2016 at 11:59 PM
// CIS 199-75
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog4
{
    // LibraryBook class declaration with one constructor 
    public class LibraryBook
    {
        private string _title;          // Backing field to hold the title
        private string _author;         // Backing field to hold the author
        private string _publisher;      // Backing field to hold the publisher
        private int _copyrightYear;     // Backing field to hold the copyright year
        private string _callNumber;     // Backing field to hold the call number
        private bool _checkedOutStatus; // Backing field to hold the checked out status 

        // 5 Parameter Constructor
        // Precondition: coprightyear >= 0
        // Postcondition: The LibraryBook object has been initialized with the specified title, author, publisher, copyright year
        //                and call number
        public LibraryBook(string title, string author, string publisher, int copyrightyear, string callnumber)
        {
            Title = title;                  // Set title property
            Author = author;                // Set author property
            Publisher = publisher;          // Set publisher property
            CopyrightYear = copyrightyear;  // Set copyright year property
            CallNumber = callnumber;        // Set call number property
            _checkedOutStatus = false;      // Set a false value if the checked out status is on the shelf
        }

        // Name properties
        public string Title
        {
            // Precondition: none
            // Postcondition: The title has been returned
            get
            {
                return _title;
            }
            // Precondition: none
            // Postcondition: The title has been set to the specified value
            set
            {
                _title = value;
            }
        }

        public string Author
        {
            // Precondition: none
            // Postcondition: The author has been returned
            get
            {
                return _author;
            }
            // Precondition: none
            // Postcondition: The author has been set to the specified value
            set
            {
                _author = value;
            }
        }

        public string Publisher
        {
            // Precondition: none
            // Postcondition: The publisher has been returned
            get
            {
                return _publisher;
            }
            // Precondition: none
            // Postcondition: The publisher has been set to the specified value
            set
            {
                _publisher = value;
            }
        }

        public int CopyrightYear
        {
            // Precondition: none
            // Postcondition: The copyright year has been returned
            get
            {
                return _copyrightYear;
            }
            // Precondition: value >= 0
            // Postcondition: The copyright year has been set to the specified value
            set
            {
                if (value >= 0)
                {
                    _copyrightYear = value;
                }
                else
                {
                    _copyrightYear = 2016;
                }
            }
        }

        public string CallNumber
        {
            // Precondition: none
            // Postcondition: The call number is returned
            get
            {
                return _callNumber;
            }
            // Precondition: none
            // Postcondition: The call number has been set to the specified value
            set
            {
                _callNumber = value;
            }
        }

        // Precondition: none
        // Postcondition: The checked out status is returned
        public bool IsCheckedOut()
        {
            return _checkedOutStatus;
        }

        // Precondition: none
        // Postcondition: The checked out status returns a true if the book has been checked out
        public void CheckOut()
        {
            _checkedOutStatus = true;
        }

        // Precondition: none
        // Postcondition: The checkout status returns a false if the book has been returned
        public void ReturnToShelf()
        {
            _checkedOutStatus = false;
        }

        // Create object
        // Precondition: none
        // Postcondition: A string is returned presenting the added library book in the listbox
        public override string ToString()
        {
            string result;  // Builds results in steps

            result = "Title: " + Title + Environment.NewLine + "Author: " + Author + Environment.NewLine + "Publisher: " + 
                Publisher + Environment.NewLine + "Copyright Year: " + CopyrightYear.ToString("D4") + Environment.NewLine + 
                "Call Number: " + CallNumber + Environment.NewLine + "Checked Out?: " + IsCheckedOut();

            return result;  // Returns the calculated result
        }
    }
}
