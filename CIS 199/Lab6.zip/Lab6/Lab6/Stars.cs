﻿// Grading ID: B1403
// Lab 6
// Due Date: Sunday October 30, 2016 at 11:59 p.m.
// CIS 199-75
// This application displays 4 different lining-up patterns consisting of stars.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6
{
    class Stars
    {
        static void Main(string[] args) // Display the number of command line arguments
        {
            const int MAX_ROWS = 10;    // Holds a constant value of 10 maximm rows
            const int MIN_ROWS = 1;     // Holds a constant value of a minimum row of 1

            // Pattern A
            Console.WriteLine("\nPattern A\n");
            for (int row = MIN_ROWS; row <= MAX_ROWS; row++)
            {
                for (int star = MIN_ROWS; star <= row; star++)
                    Console.Write("*");
                Console.WriteLine();
            }

            // Pattern B
            Console.WriteLine("\nPattern B\n");

            for (int row = MAX_ROWS; row >= MIN_ROWS; row--)
            {
                for (int star = MIN_ROWS; star <= row; star++)
                    Console.Write("*");
                Console.WriteLine();
            }

            // Pattern C
            Console.WriteLine("\nPattern C\n");
            for (int row = MAX_ROWS; row >= MIN_ROWS; row--)
            {
                for (int spaces = MIN_ROWS; spaces <= MAX_ROWS - row; spaces++)
                    Console.Write(" ");
                for (int star = MIN_ROWS; star <= row; star++)
                    Console.Write("*");
                Console.WriteLine();
            }

            // Pattern D
            Console.WriteLine("\nPattern D\n");
            for (int row = MIN_ROWS; row <= MAX_ROWS; row++)
            {
                for (int spaces = MAX_ROWS; spaces > row; spaces--)
                    Console.Write(" ");
                for (int star = MIN_ROWS; star <= row; star++)
                    Console.Write("*");
                Console.WriteLine();
            }
        }
    }
}
