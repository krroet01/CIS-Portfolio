﻿// Grading ID: B1403
// Lab 9
// Due Date: Tuesday November 29, 2016 at 11:59 PM
// CIS 199-75
// This application allows a user to enter different numbers for month, day, and year. 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab9
{
    public partial class DateForm : Form
    {
        private Date myDate = new Date(1, 1, 2000); // Default values if nothing is updated

        public DateForm()
        {
            InitializeComponent();
        }

        // Precondition: none
        // Postcondition: The output label will display "01/01/2000" by default
        private void DateForm_Load(object sender, EventArgs e)
        {
            dateOutputLabel.Text = myDate.ToString(); // The output label will display the default month, day, and year numbers when the form loads
        }

        // Precondition: The month value must be between 1 and 12 inclusively in order to execute properly
        // Postcondition: The month has been set to the specified value
        private void monthButton_Click(object sender, EventArgs e)
        {
            int monthValue; // Holds the month value

            // Declares an int
            if (int.TryParse(monthTextBox.Text, out monthValue))
            {
                myDate.Month = monthValue;  // The myDate month field is changed to a number that is entered for the month value
                dateOutputLabel.Text = myDate.ToString(); // The output label will display whatever month number you've entered
            }
            else // When invalid, error message will appear
            {
                MessageBox.Show("Enter a valid month number!");
            }
        }

        // Precondition: The day value must be between 1 and 31 inclusively in order to execute properly 
        // Postcondition: The day has been set to the specified value 
        private void dayButton_Click(object sender, EventArgs e)
        {
            int dayValue;   // Holds the day value

            // Declares an int
            if (int.TryParse(dayTextBox.Text, out dayValue))
            {
                myDate.Day = dayValue;  // The myDate day field is changed to a number that is entered for the day value
                dateOutputLabel.Text = myDate.ToString(); // The output label will display whatever day number you've entered
            }
            else // When invalid, error message will appear
            {
                MessageBox.Show("Enter a valid day number!");
            }
        }

        // Precondition: The year value must be at least 0 in order to execute properly 
        // Postcondition: The year has been set to the specified value
        private void yearButton_Click(object sender, EventArgs e)
        {
            int yearValue;  // Holds the year value

            // Declares an int
            if (int.TryParse(yearTextBox.Text, out yearValue))
            {
                myDate.Year = yearValue;  // The myDate year field is changed to a number that is entered for the year value
                dateOutputLabel.Text = myDate.ToString(); // The output label will display whatever year number you've entered
            }
            else // When invalid, error message will appear
            {
                MessageBox.Show("Enter a valid year number!");
            }
        }
    }
}
