﻿// Grading ID: B1403
// Lab 9
// Due Date: Tuesday November 29, 2016 at 11:59 PM
// CIS 199-75
// This application allows a user to enter numbers for month, day, and year. 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab9
{
    // Date class declaration with one constructor that uses defaults
    public class Date
    {
        private int _month; // Field for the date's month
        private int _day;   // Field for the date's day
        private int _year;  // Field for the date's year

        // Constructor
        // Precondition: 1 <= month <= 12, 1 <= day <= 31, 0 <= year
        // Postcondition: The dat object has been initialized with the specified month, day, and year.
        public Date(int month, int day, int year)
        {
            Month = month;  // Set month property
            Day = day;      // Set day property
            Year = year;    // Set year property
        }

        // Name properties
        public int Month
        {
            // Precondition: none
            // Postcondition: The month has been returned 
            get
            {
                return _month;
            }
            // Precondition: 1 <= value <= 12
            // Postcondition: The month has been set to the specified value
            set
            {
                if (value >= 1 && value <= 12)
                {
                    _month = value;
                }
                else // When invalid, value is set to 1
                {
                    _month = 1;
                }
            }
        }
        public int Day
        {
            // Precondition: none
            // Postcondition: The day has been returned
            get
            {
                return _day;
            }
            // Precondition: 1 <= value <= 31
            // Postcondition: The day has been set to the specified value
            set
            {
                if (value >= 1 && value <= 31)
                {
                    _day = value;
                }
                else // When invalid, value is set to 1
                {
                    _day = 1;
                }
            }
        }
        public int Year
        {
            // Precondition: none
            // Postcondition: The year has been returned
            get
            {
                return _year;
            }
            // Precondition: 0 <= value
            // Postcondition: The year has been set to the specified value
            set
            {
                if (value >= 0)
                {
                    _year = value;
                }
                else // When invalid, value is set to 2000
                {
                    _year = 2000;
                }
            }
        }

        // Create object
        // Precondition: none
        // Postcondition: A string is returned presenting the date in MM/DD/YYYY format
        public override string ToString()   // override is required!
        {
            string result;  // Builds results in steps

            result = Month.ToString("D2") + "/" + Day.ToString("D2") + "/" + Year.ToString("D4");

            return result;  // Returns the calculated result
        }
    }
}
