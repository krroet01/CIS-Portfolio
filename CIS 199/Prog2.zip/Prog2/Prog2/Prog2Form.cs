﻿// Grading ID: B1403
// Program 2
// Due Date: Sunday October 16, 2016
// CIS 199-75
// This application allows a user to enter the number of credit hours they have completed and the first letter of their
// last name to see what day and time they register for classes for the next semester.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{

    public partial class Prog2Form : Form
    {
        const float SENIOR_MINIMUMHOURS = 90;       // Holds a constant value of 90 credit hours
        const float JUNIOR_MINIMUMHOURS = 60;       // Holds a constant value of 60 credit hours
        const float SOPHOMORE_MINIMUMHOURS = 30;    // Holds a constant value of 30 credit hours 
         

        public Prog2Form()
        {
            InitializeComponent();
        }

        // Determines the date and time of registration 
        private void registrationButton_Click(object sender, EventArgs e)
        {
            float creditHours;          // Holds a value for the number of credit hours
            char firstLetterLastName;   // Holds a value for a letter entered
            string date = "";           // Holds a specific date 
            string time = "";           // Holds a specific time

            // Declare a float and char
            if (float.TryParse(hoursTextBox.Text, out creditHours))
            {
                if (char.TryParse(lastNameTextBox.Text, out firstLetterLastName))
                {
                    if (char.IsLetter(firstLetterLastName))
                    {
                        firstLetterLastName = char.ToUpper(firstLetterLastName);

                        // Write your decision logic 
                        if (creditHours >= JUNIOR_MINIMUMHOURS)
                        {
                            // Upperclassmen dates
                            if (creditHours >= SENIOR_MINIMUMHOURS)
                            {
                                date = "Friday, November 4th";
                            }
                            else
                            {
                                date = "Monday, November 7th";
                            }

                            // Upperclassmen times
                            if (firstLetterLastName <= 'D')
                            {
                                time = "2:00 p.m.";
                            }
                            else if (firstLetterLastName <= 'I')
                            {
                                time = "4:00 p.m.";
                            }
                            else if (firstLetterLastName <= 'O')
                            {
                                time = "8:30 a.m.";
                            }
                            else if (firstLetterLastName <= 'S')
                            {
                                time = "10:00 a.m.";
                            }
                            else
                            {
                                time = "11:30 a.m.";
                            }
                        }
                        else
                        {
                            // Lowerclassmen dates
                            if (creditHours >= SOPHOMORE_MINIMUMHOURS)
                            {
                                if (firstLetterLastName >= 'J' && firstLetterLastName <= 'V')
                                {
                                    date = "Wednesday, November 9th";
                                }
                                else
                                {
                                    date = "Thursday, November 10th";
                                }
                            }
                            else
                            {
                                if (firstLetterLastName >= 'J' && firstLetterLastName <= 'V')
                                {
                                    date = "Friday, November 11th";
                                }
                                else
                                {
                                    date = "Monday, November 14th";
                                }
                            }

                            // Lowerclassmen times
                            if (firstLetterLastName <= 'B')
                            {
                                time = "10:00 a.m.";
                            }
                            else if (firstLetterLastName <= 'D')
                            {
                                time = "11:30 a.m.";
                            }
                            else if (firstLetterLastName <= 'F')
                            {
                                time = "2:00 p.m.";
                            }
                            else if (firstLetterLastName <= 'I')
                            {
                                time = "4:00 p.m.";
                            }
                            else if (firstLetterLastName <= 'L')
                            {
                                time = "8:30 a.m.";
                            }
                            else if (firstLetterLastName <= 'O')
                            {
                                time = "10:00 a.m.";
                            }
                            else if (firstLetterLastName <= 'Q')
                            {
                                time = "11:30 a.m.";
                            }
                            else if (firstLetterLastName <= 'S')
                            {
                                time = "2:00 p.m.";
                            }
                            else if (firstLetterLastName <= 'V')
                            {
                                time = "4:00 p.m.";
                            }
                            else
                            {
                                time = "8:30 a.m.";
                            }
                        }

                        // Displays data in the registration output label and adds "at" in between the date and time data
                        registrationOutputLabel.Text = date + " at " + time;
                    } 
                    else
                    {
                        MessageBox.Show("Enter a letter"); // Error if anything other than a letter is entered into the firstLetterLastName textbox
                    }
                }
                else
                {
                    MessageBox.Show("Enter one letter"); // Error if anything other than ONE letter is entered into the firstLetterLastName textbox
                }
            }
            else
            {
                MessageBox.Show("Enter number of credit hours"); // Error if anything other than a number is entered into the credit hours textbox
            }
        }
    }
}
