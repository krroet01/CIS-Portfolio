﻿namespace Lab8
{
    partial class Lab8Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.distanceLabel = new System.Windows.Forms.Label();
            this.priceLabel = new System.Windows.Forms.Label();
            this.milesTextBox = new System.Windows.Forms.TextBox();
            this.priceOutputLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.companyLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // distanceLabel
            // 
            this.distanceLabel.AutoSize = true;
            this.distanceLabel.Location = new System.Drawing.Point(37, 43);
            this.distanceLabel.Name = "distanceLabel";
            this.distanceLabel.Size = new System.Drawing.Size(102, 13);
            this.distanceLabel.TabIndex = 0;
            this.distanceLabel.Text = "Trip Distance (miles)";
            // 
            // priceLabel
            // 
            this.priceLabel.AutoSize = true;
            this.priceLabel.Location = new System.Drawing.Point(50, 126);
            this.priceLabel.Name = "priceLabel";
            this.priceLabel.Size = new System.Drawing.Size(79, 13);
            this.priceLabel.TabIndex = 1;
            this.priceLabel.Text = "Ticket Price ($)";
            // 
            // milesTextBox
            // 
            this.milesTextBox.Location = new System.Drawing.Point(145, 40);
            this.milesTextBox.Name = "milesTextBox";
            this.milesTextBox.Size = new System.Drawing.Size(100, 20);
            this.milesTextBox.TabIndex = 2;
            // 
            // priceOutputLabel
            // 
            this.priceOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.priceOutputLabel.Location = new System.Drawing.Point(135, 120);
            this.priceOutputLabel.Name = "priceOutputLabel";
            this.priceOutputLabel.Size = new System.Drawing.Size(100, 25);
            this.priceOutputLabel.TabIndex = 3;
            this.priceOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(103, 79);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 4;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // companyLabel
            // 
            this.companyLabel.AutoSize = true;
            this.companyLabel.Location = new System.Drawing.Point(66, 9);
            this.companyLabel.Name = "companyLabel";
            this.companyLabel.Size = new System.Drawing.Size(158, 13);
            this.companyLabel.TabIndex = 5;
            this.companyLabel.Text = "Whippet Bus Co. Ticket Pricing:";
            // 
            // Lab8Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 161);
            this.Controls.Add(this.companyLabel);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.priceOutputLabel);
            this.Controls.Add(this.milesTextBox);
            this.Controls.Add(this.priceLabel);
            this.Controls.Add(this.distanceLabel);
            this.Name = "Lab8Form";
            this.Text = "Lab 8";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label distanceLabel;
        private System.Windows.Forms.Label priceLabel;
        private System.Windows.Forms.TextBox milesTextBox;
        private System.Windows.Forms.Label priceOutputLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label companyLabel;
    }
}

