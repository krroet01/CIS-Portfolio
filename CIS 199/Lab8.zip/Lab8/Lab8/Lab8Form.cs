﻿// Grading ID: B1403
// Lab 8
// Due Date: Sunday November 13, 2016 at 11:59 PM
// CIS 199-75
// This application allows a user to enter the desired number of miles they wish to travel, and calculate the ticket price.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab8
{
    public partial class Lab8Form : Form
    {
        public Lab8Form()
        {
            InitializeComponent();
        }

        // Precondition: The distance in miles inputed must be a number no less than 0.

        // Postcondition: If the distance is 99 miles or less, the ticket price will be $25. If the distance is at least 100
        // and no more than 299, the ticket price will be $40. If the distance is at least 300 and no more than 499, the ticket
        // price will be $55. If the distance is at least 500, the ticket price will be $70.
        private void calculateButton_Click(object sender, EventArgs e)
        {
            int[] distanceRangeLowLimit = { 0, 100, 300, 500 }; // Holds an array of the minimum limit ranges of miles
            double[] price = { 25, 40, 55, 70 };                // Holds an array of different prices used for matching
            bool found = false;                                 // Declares whether or not the matching #s in the array are found
            double customerTicketPrice = 0;                     // Ticket price initialized to 0
            int numOfMiles;                                     // Holds a value for the number of miles

            int index = distanceRangeLowLimit.Length - 1;       // Start from end since lower limits (loop counter)

            // 
            if (int.TryParse(milesTextBox.Text, out numOfMiles))
            {
                if (numOfMiles >= 0) // Declares the number of miles must be at least 0
                {
                    while (index >= 0 && !found)    // Gather the numbers in the distance array
                    {
                        if (numOfMiles >= distanceRangeLowLimit[index])
                        {
                            found = true;
                        }
                        else
                        {
                            --index;
                        }
                    }

                    // Match the distance array numbers to the numbers in the price array
                    if (found)
                    {
                        customerTicketPrice = price[index];
                    }
                }
                else
                {
                    MessageBox.Show("Error: Enter positive number!"); // Number must be at least 0
                }
            }
            // Displays the ticket price in the output label
            priceOutputLabel.Text = customerTicketPrice.ToString("n2");
        }
    }
}
