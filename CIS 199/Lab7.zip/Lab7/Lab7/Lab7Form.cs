﻿// Student ID: B1403
// Lab 7
// Due Date: Sunday November 6, 2016 at 11:59 p.m.
// CIS 199-75
// This application allows a user to enter a month number and see it translated in 3 different languages.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab7
{
    public partial class Lab7Form : Form
    {
        public Lab7Form()
        {
            InitializeComponent();
        }

        // Precondition: The monthNumber must be no less than 1 and no more than 12
        // Postcondition: The monthNumber is used to look up the appropriate month in the English language
        private string GetEnglishMonth(int monthNumber)
        {
            // Create an array of strings
            string[] englishMonthNames = {"January", "February", "March", "April", "May", "June", "July", "August", "September",
                                          "October", "November", "December"};

            // Pass the array to the GetEnglishMonth method
            if (monthNumber >= 1 && monthNumber <= 12) 
            {
                return englishMonthNames[monthNumber - 1];
            }
            else
            {
                return "Error!";
            }
        }

        // Precondition: The monthNumber must be no less than 1 and no more than 12
        // Postcondition: The monthNumber is used to look up the appropriate month in the Spanish language
        private string GetSpanishMonth(int monthNumber)
        {
            // Create an array of strings
            string[] spanishMonthNames = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre",
                                          "Octubre", "Noviembre", "Diciembre"};

            // Pass the array to the GetSpanishMonth method
            if (monthNumber >= 1 && monthNumber <= 12)
            {
                return spanishMonthNames[monthNumber - 1];
            }
            else
            {
                return "Error!";
            }
        }

        // Precondition: The monthNumber must be no less than 1 and no more than 12
        // Postcondition: THe monthNumber is used to look up the appropriate month in the Italian language 
        private string GetItalianMonth(int monthNumber)
        {
            // Create an array of strings
            string[] italianMonthNames = {"Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Guigno", "Luglio", "Agosto",
                                          "Settembre", "Ottobre", "Novembre", "Dicembre"};

            // Pass the array to the GetItalianMonth method
            if (monthNumber >= 1 && monthNumber <= 12)
            {
                return italianMonthNames[monthNumber - 1];
            }
            else
            {
                return "Error!";
            }
        }

        // Enter a number no less than 1 and no more than 12 and look up the month name in the English, Spanish, and Italian
        // languages.
        private void lookupButton_Click(object sender, EventArgs e)
        {
            int monthNumber;        // Holds a value for the month number
            string monthName = "";  // Holds a string for a month name

            if (int.TryParse(monthnumberTextBox.Text, out monthNumber))
            {
                if (englishRadioButton.Checked) // The English language radio button will run if checked
                {
                    monthName = GetEnglishMonth(monthNumber);
                }
                else if (spanishRadioButton.Checked) // The Spanish language radio button will run if checked
                {
                    monthName = GetSpanishMonth(monthNumber);
                }
                else // The Italian language radio button will run if checked
                {
                    monthName = GetItalianMonth(monthNumber);
                }    
            }
            else
            {
                MessageBox.Show("Invalid month number!");
            }

            // Displays the month name in the output label
            monthOutputLabel.Text = monthName;
        }
    }
}
