﻿namespace Lab7
{
    partial class Lab7Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.monthnumberLabel = new System.Windows.Forms.Label();
            this.monthnumberTextBox = new System.Windows.Forms.TextBox();
            this.languageGroupBox = new System.Windows.Forms.GroupBox();
            this.italianRadioButton = new System.Windows.Forms.RadioButton();
            this.spanishRadioButton = new System.Windows.Forms.RadioButton();
            this.englishRadioButton = new System.Windows.Forms.RadioButton();
            this.monthOutputLabel = new System.Windows.Forms.Label();
            this.lookupButton = new System.Windows.Forms.Button();
            this.languageGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // monthnumberLabel
            // 
            this.monthnumberLabel.AutoSize = true;
            this.monthnumberLabel.Location = new System.Drawing.Point(56, 28);
            this.monthnumberLabel.Name = "monthnumberLabel";
            this.monthnumberLabel.Size = new System.Drawing.Size(50, 13);
            this.monthnumberLabel.TabIndex = 0;
            this.monthnumberLabel.Text = "Month #:";
            // 
            // monthnumberTextBox
            // 
            this.monthnumberTextBox.Location = new System.Drawing.Point(112, 25);
            this.monthnumberTextBox.Name = "monthnumberTextBox";
            this.monthnumberTextBox.Size = new System.Drawing.Size(100, 20);
            this.monthnumberTextBox.TabIndex = 1;
            // 
            // languageGroupBox
            // 
            this.languageGroupBox.Controls.Add(this.italianRadioButton);
            this.languageGroupBox.Controls.Add(this.spanishRadioButton);
            this.languageGroupBox.Controls.Add(this.englishRadioButton);
            this.languageGroupBox.Location = new System.Drawing.Point(59, 66);
            this.languageGroupBox.Name = "languageGroupBox";
            this.languageGroupBox.Size = new System.Drawing.Size(153, 100);
            this.languageGroupBox.TabIndex = 2;
            this.languageGroupBox.TabStop = false;
            this.languageGroupBox.Text = "Choose Language";
            // 
            // italianRadioButton
            // 
            this.italianRadioButton.AutoSize = true;
            this.italianRadioButton.Location = new System.Drawing.Point(18, 64);
            this.italianRadioButton.Name = "italianRadioButton";
            this.italianRadioButton.Size = new System.Drawing.Size(96, 17);
            this.italianRadioButton.TabIndex = 4;
            this.italianRadioButton.Text = "Italian (Italiano)";
            this.italianRadioButton.UseVisualStyleBackColor = true;
            // 
            // spanishRadioButton
            // 
            this.spanishRadioButton.AutoSize = true;
            this.spanishRadioButton.Location = new System.Drawing.Point(18, 42);
            this.spanishRadioButton.Name = "spanishRadioButton";
            this.spanishRadioButton.Size = new System.Drawing.Size(110, 17);
            this.spanishRadioButton.TabIndex = 3;
            this.spanishRadioButton.Text = "Spanish (Espanol)";
            this.spanishRadioButton.UseVisualStyleBackColor = true;
            // 
            // englishRadioButton
            // 
            this.englishRadioButton.AutoSize = true;
            this.englishRadioButton.Checked = true;
            this.englishRadioButton.Location = new System.Drawing.Point(18, 19);
            this.englishRadioButton.Name = "englishRadioButton";
            this.englishRadioButton.Size = new System.Drawing.Size(59, 17);
            this.englishRadioButton.TabIndex = 2;
            this.englishRadioButton.TabStop = true;
            this.englishRadioButton.Text = "English";
            this.englishRadioButton.UseVisualStyleBackColor = true;
            // 
            // monthOutputLabel
            // 
            this.monthOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.monthOutputLabel.Location = new System.Drawing.Point(59, 178);
            this.monthOutputLabel.Name = "monthOutputLabel";
            this.monthOutputLabel.Size = new System.Drawing.Size(153, 27);
            this.monthOutputLabel.TabIndex = 0;
            this.monthOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lookupButton
            // 
            this.lookupButton.Location = new System.Drawing.Point(98, 217);
            this.lookupButton.Name = "lookupButton";
            this.lookupButton.Size = new System.Drawing.Size(75, 23);
            this.lookupButton.TabIndex = 5;
            this.lookupButton.Text = "Look Up";
            this.lookupButton.UseVisualStyleBackColor = true;
            this.lookupButton.Click += new System.EventHandler(this.lookupButton_Click);
            // 
            // Lab7Form
            // 
            this.AcceptButton = this.lookupButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.lookupButton);
            this.Controls.Add(this.monthOutputLabel);
            this.Controls.Add(this.languageGroupBox);
            this.Controls.Add(this.monthnumberTextBox);
            this.Controls.Add(this.monthnumberLabel);
            this.Name = "Lab7Form";
            this.Text = "Lab 7";
            this.languageGroupBox.ResumeLayout(false);
            this.languageGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label monthnumberLabel;
        private System.Windows.Forms.TextBox monthnumberTextBox;
        private System.Windows.Forms.GroupBox languageGroupBox;
        private System.Windows.Forms.RadioButton italianRadioButton;
        private System.Windows.Forms.RadioButton spanishRadioButton;
        private System.Windows.Forms.RadioButton englishRadioButton;
        private System.Windows.Forms.Label monthOutputLabel;
        private System.Windows.Forms.Button lookupButton;
    }
}

