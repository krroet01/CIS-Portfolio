﻿// Grading ID: B1403
// Program 3
// Due Date: Sunday November 20, 2016
// CIS 199-75
// This application allows a user to enter the number of credit hours they have completed and the first letter of their
// last name to see what day and time they register for classes for the Spring 2017 semester.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{

    public partial class Prog3Form : Form
    {
        public Prog3Form()
        {
            InitializeComponent();
        }

        // Precondition: Total credit hours entered must be a valid integer, and last name textbox must contain an upper cast letter
        // Postcondition: The total credit hours and first letter of last name entered are used to find the date and time of reistration
        private void registrationButton_Click(object sender, EventArgs e)
        {
            const float SENIOR_MINIMUMHOURS = 90;       // Minimum credit hours for senior class
            const float JUNIOR_MINIMUMHOURS = 60;       // Minimum credit hours for junior class
            const float SOPHOMORE_MINIMUMHOURS = 30;    // Minimum credit hours for sophomore class 

            const string DAY1 = "Friday, November 4th";     // 1st day of registration
            const string DAY2 = "Monday, November 7th";     // 2nd day of registration
            const string DAY3 = "Wednesday, November 9th";  // 3rd day of registration
            const string DAY4 = "Thursday, November 10th";  // 4th day of registration
            const string DAY5 = "Friday, November 11th";    // 5th day of registration
            const string DAY6 = "Monday, November 14th";    // 6th day of registration

            const string TIME1 = "8:30 a.m.";  // 1st time block
            const string TIME2 = "10:00 a.m."; // 2nd time block
            const string TIME3 = "11:30 a.m."; // 3rd time block
            const string TIME4 = "2:00 p.m.";  // 4th time block
            const string TIME5 = "4:00 p.m.";  // 5th time block

            float creditHours;          // Entered number of credit hours
            char firstLetterLastName;   // First letter of last name, as char
            string lastNameStr;         // Entered last name
            string date = "Error";      // Holds a specific date of registration
            string time = "Error";      // Holds a specific time of registration

            // Declare a float and char
            if (float.TryParse(hoursTextBox.Text, out creditHours) && creditHours >= 0) // Valid hours
            {
                lastNameStr = lastNameTextBox.Text;
                if (lastNameStr.Length > 0) // Empty string?
                {
                    firstLetterLastName = lastNameStr[0];   // First char of last name
                    firstLetterLastName = char.ToUpper(firstLetterLastName);    // Ensure upper case

                    if (char.IsLetter(firstLetterLastName))
                    {
                        // Juniors and seniors share the same schedule but different days
                        if (creditHours >= JUNIOR_MINIMUMHOURS)
                        {
                            // seniors registration day
                            if (creditHours >= SENIOR_MINIMUMHOURS)
                            {
                                date = DAY1;
                            }
                            else // juniors registration day
                            {
                                date = DAY2;
                            }

                            char[] srJrLetters = { 'A', 'E', 'J', 'P', 'T' };           // lower limits of jr-sr letter ranges
                            string[] srJrTimes = { TIME4, TIME5, TIME1, TIME2, TIME3 }; // corresponding times
                            int index = srJrLetters.Length - 1;                         // declaring an index variable

                            // Upperclassmen times
                            while (firstLetterLastName < srJrLetters[index])    // Loop searches while firstLetterLastName has a lower value than the letter in srJrLetters' array
                            {
                                --index;    // decrements until firstLetterLastName has a higher value than the letter in srJrLetters' array
                                time = srJrTimes[index];    // assigns time variable a time corresponding to srJrLetters' index
                            }
                        }
                        else // Sophomores and freshmen share the same two schedules but different days 
                        {
                            // Sophomores registration days
                            if (creditHours >= SOPHOMORE_MINIMUMHOURS)
                            {
                                // Sophomore's first registration day
                                if (firstLetterLastName >= 'J' && firstLetterLastName <= 'V')
                                {
                                    date = DAY3;
                                }
                                else // Sophomore's second registration day
                                {
                                    date = DAY4;
                                }
                            }
                            else // Freshmen registration days
                            {
                                // Freshmen's first registration day
                                if (firstLetterLastName >= 'J' && firstLetterLastName <= 'V')
                                {
                                    date = DAY5;
                                }
                                else // Freshmen's second registration day
                                {
                                    date = DAY6;
                                }
                            }

                            char[] soFrLetters = { 'A', 'C', 'E', 'G', 'J', 'M', 'P', 'R', 'T', 'W' }; // lower limits of so-fr letter ranges
                            string[] soFrTimes = { TIME2, TIME3, TIME4, TIME5, TIME1, TIME2, TIME3, TIME4, TIME5, TIME1 }; // corresponding times
                            int index = soFrLetters.Length - 1; // declaring an index variable

                            // Lowerclassmen times
                            while (firstLetterLastName < soFrLetters[index]) // Loop searches while firstLetterLastName has a lower value than the letter in soFrLetters' array
                            {
                                --index;    // decrements until firstLetterLastName has a higher value than the letter in soFrLetters' array
                                time = soFrTimes[index];    // assigns time variable a time corresponding to soFrLetters' index
                            }
                            
                        }

                        // Displays data in the registration output label and adds "at" in between the date and time data
                        registrationOutputLabel.Text = date + " at " + time;
                    } 
                    else
                    {
                        MessageBox.Show("Enter a letter!"); // Error if anything other than a letter is entered into the firstLetterLastName textbox
                    }
                }
                else
                {
                    MessageBox.Show("Enter one letter!"); // Error if anything other than ONE letter is entered into the firstLetterLastName textbox
                }
            }
            else
            {
                MessageBox.Show("Enter number valid number of credit hours earned!"); // Error if anything other than a number is entered into the credit hours textbox
            }
        }
    }
}
