﻿namespace Lab3
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.enterPricelLabel = new System.Windows.Forms.Label();
            this.mealPriceTextBox = new System.Windows.Forms.TextBox();
            this.lowPercentLabel = new System.Windows.Forms.Label();
            this.mediumPercentLabel = new System.Windows.Forms.Label();
            this.highPercentLabel = new System.Windows.Forms.Label();
            this.lowpercentOutputLabel = new System.Windows.Forms.Label();
            this.mediumpercentOutputLabel = new System.Windows.Forms.Label();
            this.highpercentOutputLabel = new System.Windows.Forms.Label();
            this.calculatetipButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // enterPricelLabel
            // 
            this.enterPricelLabel.AutoSize = true;
            this.enterPricelLabel.Location = new System.Drawing.Point(61, 20);
            this.enterPricelLabel.Name = "enterPricelLabel";
            this.enterPricelLabel.Size = new System.Drawing.Size(98, 13);
            this.enterPricelLabel.TabIndex = 0;
            this.enterPricelLabel.Text = "Enter price of meal:";
            // 
            // mealPriceTextBox
            // 
            this.mealPriceTextBox.Location = new System.Drawing.Point(165, 17);
            this.mealPriceTextBox.Name = "mealPriceTextBox";
            this.mealPriceTextBox.Size = new System.Drawing.Size(100, 20);
            this.mealPriceTextBox.TabIndex = 1;
            // 
            // lowPercentLabel
            // 
            this.lowPercentLabel.AutoSize = true;
            this.lowPercentLabel.Location = new System.Drawing.Point(132, 70);
            this.lowPercentLabel.Name = "lowPercentLabel";
            this.lowPercentLabel.Size = new System.Drawing.Size(25, 13);
            this.lowPercentLabel.TabIndex = 0;
            this.lowPercentLabel.Text = "xx%";
            // 
            // mediumPercentLabel
            // 
            this.mediumPercentLabel.AutoSize = true;
            this.mediumPercentLabel.Location = new System.Drawing.Point(132, 114);
            this.mediumPercentLabel.Name = "mediumPercentLabel";
            this.mediumPercentLabel.Size = new System.Drawing.Size(25, 13);
            this.mediumPercentLabel.TabIndex = 0;
            this.mediumPercentLabel.Text = "xx%";
            // 
            // highPercentLabel
            // 
            this.highPercentLabel.AutoSize = true;
            this.highPercentLabel.Location = new System.Drawing.Point(132, 158);
            this.highPercentLabel.Name = "highPercentLabel";
            this.highPercentLabel.Size = new System.Drawing.Size(25, 13);
            this.highPercentLabel.TabIndex = 0;
            this.highPercentLabel.Text = "xx%";
            // 
            // lowpercentOutputLabel
            // 
            this.lowpercentOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lowpercentOutputLabel.Location = new System.Drawing.Point(165, 65);
            this.lowpercentOutputLabel.Name = "lowpercentOutputLabel";
            this.lowpercentOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.lowpercentOutputLabel.TabIndex = 5;
            this.lowpercentOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mediumpercentOutputLabel
            // 
            this.mediumpercentOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mediumpercentOutputLabel.Location = new System.Drawing.Point(165, 109);
            this.mediumpercentOutputLabel.Name = "mediumpercentOutputLabel";
            this.mediumpercentOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.mediumpercentOutputLabel.TabIndex = 6;
            this.mediumpercentOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // highpercentOutputLabel
            // 
            this.highpercentOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.highpercentOutputLabel.Location = new System.Drawing.Point(165, 153);
            this.highpercentOutputLabel.Name = "highpercentOutputLabel";
            this.highpercentOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.highpercentOutputLabel.TabIndex = 7;
            this.highpercentOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // calculatetipButton
            // 
            this.calculatetipButton.Location = new System.Drawing.Point(119, 206);
            this.calculatetipButton.Name = "calculatetipButton";
            this.calculatetipButton.Size = new System.Drawing.Size(93, 23);
            this.calculatetipButton.TabIndex = 2;
            this.calculatetipButton.Text = "Calculate Tip";
            this.calculatetipButton.UseVisualStyleBackColor = true;
            this.calculatetipButton.Click += new System.EventHandler(this.calculatetipButton_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 261);
            this.Controls.Add(this.calculatetipButton);
            this.Controls.Add(this.highpercentOutputLabel);
            this.Controls.Add(this.mediumpercentOutputLabel);
            this.Controls.Add(this.lowpercentOutputLabel);
            this.Controls.Add(this.highPercentLabel);
            this.Controls.Add(this.mediumPercentLabel);
            this.Controls.Add(this.lowPercentLabel);
            this.Controls.Add(this.mealPriceTextBox);
            this.Controls.Add(this.enterPricelLabel);
            this.Name = "Form3";
            this.Text = "Lab 3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label enterPricelLabel;
        private System.Windows.Forms.TextBox mealPriceTextBox;
        private System.Windows.Forms.Label lowPercentLabel;
        private System.Windows.Forms.Label mediumPercentLabel;
        private System.Windows.Forms.Label highPercentLabel;
        private System.Windows.Forms.Label lowpercentOutputLabel;
        private System.Windows.Forms.Label mediumpercentOutputLabel;
        private System.Windows.Forms.Label highpercentOutputLabel;
        private System.Windows.Forms.Button calculatetipButton;
    }
}

