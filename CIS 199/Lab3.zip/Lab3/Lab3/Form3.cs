﻿// Grading ID: B1403
// Lab 3
// Due: September 25, 2016 at 11:59 p.m.
// CIS 199-75 
// This application allows the user to enter a number, in this case a potential price of a meal, and calculate three 
// different percent tips.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab3
{
    public partial class Form3 : Form
    {
        const double TIPRATELOW = 0.15;    // A constant tip rate of 15%
        const double TIPRATEMEDIUM = 0.18; // A constant tip rate of 18%
        const double TIPRATEHIGH = 0.20;   // A constant tip rate of 20%

        public Form3()
        {
            InitializeComponent();
        }

        // Rounds your constant tip rates to whole numbers
        private void Form3_Load(object sender, EventArgs e)
        {
            lowPercentLabel.Text = TIPRATELOW.ToString("p0");
            mediumPercentLabel.Text = TIPRATEMEDIUM.ToString("p0");
            highPercentLabel.Text = TIPRATEHIGH.ToString("p0");  
        }

        // Calculates the tip amounts based on the original price of your meal 
        private void calculatetipButton_Click(object sender, EventArgs e)
        {
            double originalPrice;   // Holds the meal's original price
            double tipAmountLow;    // Holds the value for the lowest tip amount
            double tipAmountMedium; // Holds the value for the medium tip amount
            double tipAmountHigh;   // Holds the value for the highest tip amount

            // Gets the meal's original price
            originalPrice = double.Parse(mealPriceTextBox.Text);

            // Calculates the amount of the tips
            tipAmountLow = originalPrice * TIPRATELOW;  
            tipAmountMedium = originalPrice * TIPRATEMEDIUM; 
            tipAmountHigh = originalPrice * TIPRATEHIGH;     
            
            // Displays the tip prices
            lowpercentOutputLabel.Text = tipAmountLow.ToString("c");        
            mediumpercentOutputLabel.Text = tipAmountMedium.ToString("c");  
            highpercentOutputLabel.Text = tipAmountHigh.ToString("c");   
        }
    }
}