﻿// Grading ID - B1403
// This is Lab 1
// The due date for this lab is September 7, 2016 at 11:59 P.M.
// This is CIS 199-75
// This program displays my name and a headshot of me and has three buttons that tell my favorite hobbies, favorite book, and favorite movie.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab1
{
    public partial class Lab1Form : Form
    {
        public Lab1Form()
        {
            InitializeComponent();
        }

        private void Lab1Form_Load(object sender, EventArgs e)
        {

        }

        private void HobbiesButton_Click(object sender, EventArgs e)
        {
            // Click the Hobbies Button. This will take you to a window that tells you what my favorite hobbies are.
            MessageBox.Show("My favorite hobbies include musical theatre, painting, shopping, and binge-watching Friends on Netflix.");
        }

        private void BookButton_Click(object sender, EventArgs e)
        {
            // Click the Book Button. This will take you to a window that tells you what my favorite book is.
            MessageBox.Show("My favorite book is 'To Kill A Mockingbird' by Harper Lee.");
        }

        private void MovieButton_Click(object sender, EventArgs e)
        {
            // Click the Movie Button. This will take you to a window that tells you what my favorite movie is.
            MessageBox.Show("My favorite movie is Legally Blonde.");
        }
    }
}
