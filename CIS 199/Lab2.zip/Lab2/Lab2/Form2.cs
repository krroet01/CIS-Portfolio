﻿/* Grading ID: B1403, Lab 2, Due Date: Sunday September 18, 2016 at 11:59 p.m., CIS 199-75. This application allows the 
user to enter their first name, middle name, last name and preferred title and to view it in six different formats. */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        // Concatenates the input and builds the output string for Format 1.
        private void format1Button_Click(object sender, EventArgs e)
        {
            string output; // The purpose of this variable is to tell the compiler that the plan is to use a variable of a specific name to store a particular type of data. 

            output = preferredtitleTextBox.Text + " " +
                firstnameTextBox.Text + " " + 
                middlenameTextBox.Text + " " +
                lastnameTextBox.Text; // The purpose of this variable is to make the output cox display your full name including your preferred title.

            nameoutputLabel.Text = output; // The purpose of this variable is to display the output string in the Label control.
        }

        // Concatenates the input and builds the output string for Format 2.
        private void format2Button_Click(object sender, EventArgs e)
        {
            string output; // The purpose of this variable is to tell the compiler that the plan is to use a variable of a specific name to store a particular type of data.

            output = firstnameTextBox.Text + " " +
                middlenameTextBox.Text + " " +
                lastnameTextBox.Text; // The purpose of this variable is to make the output box display your full name withput your preferred title.

            nameoutputLabel.Text = output; // The purpose of this variable is to display the output string in the Label control.
        }

        // Concatenates the input and builds the output string for Format 3.
        private void format3Button_Click(object sender, EventArgs e)
        {
            string output; // The purpose of this variable is to tell the compiler that the plan is to use a variable of a specific name to store a particular type of data.

            output = firstnameTextBox.Text + " " +
                lastnameTextBox.Text; // The purpose of this variable is to make the output box display only your first and last name.

            nameoutputLabel.Text = output; // The purpose of this variable is to display the output string in the Label control.
        }

        // Concatenates the input and builds the output string for Format 4.
        private void format4Button_Click(object sender, EventArgs e)
        {
            string output; // The purpose of this variable is to tell the compiler that the plan is to use a variable of a specific name to store a particular type of data.

            output = lastnameTextBox.Text + ", " +
                firstnameTextBox.Text + " " +
                middlenameTextBox.Text + ", " +
                preferredtitleTextBox.Text; // The purpose of this variable is to make the output box display your last name first, your first and middle names following, then your preferred title.

            nameoutputLabel.Text = output; // The purpose of this variable is to display the output string in the Label control.
        }

        // Concatenates the input and builds the output string for Format 5.
        private void format5Button_Click(object sender, EventArgs e)
        {
            string output; // The purpose of this variable is to tell the compiler that the plan is to use a variable of a specific name to store a particular type of data.

            output = lastnameTextBox.Text + ", " +
                firstnameTextBox.Text + " " +
                middlenameTextBox.Text; // The purpose of this variable is to make the output box display your full name without your preferred title with your last name first.

            nameoutputLabel.Text = output; // The purpose of this variable is to display the output string in the Label control.
        }

        // Concatenates the input and builds the output string for Format 6.
        private void format6Button_Click(object sender, EventArgs e)
        {
            string output; // The purpose of this variable is to tell the compiler that the plan is to use a variable of a specific name to store a particular type of data.

            output = lastnameTextBox.Text + ", " +
                firstnameTextBox.Text; // The purpose of this variable is to make the output box display your last name then first name.

            nameoutputLabel.Text = output; // The purpose of this variable is to display the output string in the Label control.
        }
    }
}
