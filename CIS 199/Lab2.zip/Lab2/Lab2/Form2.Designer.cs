﻿namespace Lab2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstnameTextBox = new System.Windows.Forms.TextBox();
            this.lastnameTextBox = new System.Windows.Forms.TextBox();
            this.middlenameTextBox = new System.Windows.Forms.TextBox();
            this.preferredtitleTextBox = new System.Windows.Forms.TextBox();
            this.firstnameLabel = new System.Windows.Forms.Label();
            this.middlenameLabel = new System.Windows.Forms.Label();
            this.lastnameLabel = new System.Windows.Forms.Label();
            this.preferredtitleLabel = new System.Windows.Forms.Label();
            this.nameoutputLabel = new System.Windows.Forms.Label();
            this.format1Button = new System.Windows.Forms.Button();
            this.format2Button = new System.Windows.Forms.Button();
            this.format3Button = new System.Windows.Forms.Button();
            this.format4Button = new System.Windows.Forms.Button();
            this.format5Button = new System.Windows.Forms.Button();
            this.format6Button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // firstnameTextBox
            // 
            this.firstnameTextBox.Location = new System.Drawing.Point(249, 12);
            this.firstnameTextBox.Name = "firstnameTextBox";
            this.firstnameTextBox.Size = new System.Drawing.Size(100, 20);
            this.firstnameTextBox.TabIndex = 0;
            // 
            // lastnameTextBox
            // 
            this.lastnameTextBox.Location = new System.Drawing.Point(249, 64);
            this.lastnameTextBox.Name = "lastnameTextBox";
            this.lastnameTextBox.Size = new System.Drawing.Size(100, 20);
            this.lastnameTextBox.TabIndex = 2;
            // 
            // middlenameTextBox
            // 
            this.middlenameTextBox.Location = new System.Drawing.Point(249, 38);
            this.middlenameTextBox.Name = "middlenameTextBox";
            this.middlenameTextBox.Size = new System.Drawing.Size(100, 20);
            this.middlenameTextBox.TabIndex = 1;
            // 
            // preferredtitleTextBox
            // 
            this.preferredtitleTextBox.Location = new System.Drawing.Point(249, 90);
            this.preferredtitleTextBox.Name = "preferredtitleTextBox";
            this.preferredtitleTextBox.Size = new System.Drawing.Size(100, 20);
            this.preferredtitleTextBox.TabIndex = 3;
            // 
            // firstnameLabel
            // 
            this.firstnameLabel.AutoSize = true;
            this.firstnameLabel.Location = new System.Drawing.Point(168, 12);
            this.firstnameLabel.Name = "firstnameLabel";
            this.firstnameLabel.Size = new System.Drawing.Size(60, 13);
            this.firstnameLabel.TabIndex = 4;
            this.firstnameLabel.Text = "First Name:";
            // 
            // middlenameLabel
            // 
            this.middlenameLabel.AutoSize = true;
            this.middlenameLabel.Location = new System.Drawing.Point(156, 38);
            this.middlenameLabel.Name = "middlenameLabel";
            this.middlenameLabel.Size = new System.Drawing.Size(72, 13);
            this.middlenameLabel.TabIndex = 5;
            this.middlenameLabel.Text = "Middle Name:";
            // 
            // lastnameLabel
            // 
            this.lastnameLabel.AutoSize = true;
            this.lastnameLabel.Location = new System.Drawing.Point(167, 64);
            this.lastnameLabel.Name = "lastnameLabel";
            this.lastnameLabel.Size = new System.Drawing.Size(61, 13);
            this.lastnameLabel.TabIndex = 6;
            this.lastnameLabel.Text = "Last Name:";
            // 
            // preferredtitleLabel
            // 
            this.preferredtitleLabel.AutoSize = true;
            this.preferredtitleLabel.Location = new System.Drawing.Point(35, 90);
            this.preferredtitleLabel.Name = "preferredtitleLabel";
            this.preferredtitleLabel.Size = new System.Drawing.Size(193, 13);
            this.preferredtitleLabel.TabIndex = 7;
            this.preferredtitleLabel.Text = "Preferred Title (Mr., Mrs., Ms., Dr., etc.):";
            // 
            // nameoutputLabel
            // 
            this.nameoutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nameoutputLabel.Location = new System.Drawing.Point(31, 135);
            this.nameoutputLabel.Name = "nameoutputLabel";
            this.nameoutputLabel.Size = new System.Drawing.Size(318, 25);
            this.nameoutputLabel.TabIndex = 8;
            this.nameoutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // format1Button
            // 
            this.format1Button.Location = new System.Drawing.Point(31, 185);
            this.format1Button.Name = "format1Button";
            this.format1Button.Size = new System.Drawing.Size(75, 23);
            this.format1Button.TabIndex = 9;
            this.format1Button.Text = "Format 1";
            this.format1Button.UseVisualStyleBackColor = true;
            this.format1Button.Click += new System.EventHandler(this.format1Button_Click);
            // 
            // format2Button
            // 
            this.format2Button.Location = new System.Drawing.Point(112, 185);
            this.format2Button.Name = "format2Button";
            this.format2Button.Size = new System.Drawing.Size(75, 23);
            this.format2Button.TabIndex = 10;
            this.format2Button.Text = "Format 2";
            this.format2Button.UseVisualStyleBackColor = true;
            this.format2Button.Click += new System.EventHandler(this.format2Button_Click);
            // 
            // format3Button
            // 
            this.format3Button.Location = new System.Drawing.Point(193, 185);
            this.format3Button.Name = "format3Button";
            this.format3Button.Size = new System.Drawing.Size(75, 23);
            this.format3Button.TabIndex = 11;
            this.format3Button.Text = "Format 3";
            this.format3Button.UseVisualStyleBackColor = true;
            this.format3Button.Click += new System.EventHandler(this.format3Button_Click);
            // 
            // format4Button
            // 
            this.format4Button.Location = new System.Drawing.Point(274, 185);
            this.format4Button.Name = "format4Button";
            this.format4Button.Size = new System.Drawing.Size(75, 23);
            this.format4Button.TabIndex = 12;
            this.format4Button.Text = "Format 4";
            this.format4Button.UseVisualStyleBackColor = true;
            this.format4Button.Click += new System.EventHandler(this.format4Button_Click);
            // 
            // format5Button
            // 
            this.format5Button.Location = new System.Drawing.Point(71, 214);
            this.format5Button.Name = "format5Button";
            this.format5Button.Size = new System.Drawing.Size(75, 23);
            this.format5Button.TabIndex = 13;
            this.format5Button.Text = "Format 5";
            this.format5Button.UseVisualStyleBackColor = true;
            this.format5Button.Click += new System.EventHandler(this.format5Button_Click);
            // 
            // format6Button
            // 
            this.format6Button.Location = new System.Drawing.Point(233, 214);
            this.format6Button.Name = "format6Button";
            this.format6Button.Size = new System.Drawing.Size(75, 23);
            this.format6Button.TabIndex = 14;
            this.format6Button.Text = "Format 6";
            this.format6Button.UseVisualStyleBackColor = true;
            this.format6Button.Click += new System.EventHandler(this.format6Button_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 261);
            this.Controls.Add(this.format6Button);
            this.Controls.Add(this.format5Button);
            this.Controls.Add(this.format4Button);
            this.Controls.Add(this.format3Button);
            this.Controls.Add(this.format2Button);
            this.Controls.Add(this.format1Button);
            this.Controls.Add(this.nameoutputLabel);
            this.Controls.Add(this.preferredtitleLabel);
            this.Controls.Add(this.lastnameLabel);
            this.Controls.Add(this.middlenameLabel);
            this.Controls.Add(this.firstnameLabel);
            this.Controls.Add(this.preferredtitleTextBox);
            this.Controls.Add(this.middlenameTextBox);
            this.Controls.Add(this.lastnameTextBox);
            this.Controls.Add(this.firstnameTextBox);
            this.Name = "Form2";
            this.Text = "Lab2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox firstnameTextBox;
        private System.Windows.Forms.TextBox lastnameTextBox;
        private System.Windows.Forms.TextBox middlenameTextBox;
        private System.Windows.Forms.TextBox preferredtitleTextBox;
        private System.Windows.Forms.Label firstnameLabel;
        private System.Windows.Forms.Label middlenameLabel;
        private System.Windows.Forms.Label lastnameLabel;
        private System.Windows.Forms.Label preferredtitleLabel;
        private System.Windows.Forms.Label nameoutputLabel;
        private System.Windows.Forms.Button format1Button;
        private System.Windows.Forms.Button format2Button;
        private System.Windows.Forms.Button format3Button;
        private System.Windows.Forms.Button format4Button;
        private System.Windows.Forms.Button format5Button;
        private System.Windows.Forms.Button format6Button;
    }
}

