﻿namespace Lab5
{
    partial class Lab5Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fromTextBox = new System.Windows.Forms.TextBox();
            this.fromLabel = new System.Windows.Forms.Label();
            this.toTextbox = new System.Windows.Forms.TextBox();
            this.toLabel = new System.Windows.Forms.Label();
            this.whileRadioButton = new System.Windows.Forms.RadioButton();
            this.loopUsingGroupBox = new System.Windows.Forms.GroupBox();
            this.dowhileRadioButton = new System.Windows.Forms.RadioButton();
            this.forRadioButton = new System.Windows.Forms.RadioButton();
            this.runButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.numbersListBox = new System.Windows.Forms.ListBox();
            this.loopUsingGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // fromTextBox
            // 
            this.fromTextBox.Location = new System.Drawing.Point(16, 25);
            this.fromTextBox.Name = "fromTextBox";
            this.fromTextBox.Size = new System.Drawing.Size(100, 20);
            this.fromTextBox.TabIndex = 0;
            // 
            // fromLabel
            // 
            this.fromLabel.AutoSize = true;
            this.fromLabel.Location = new System.Drawing.Point(13, 9);
            this.fromLabel.Name = "fromLabel";
            this.fromLabel.Size = new System.Drawing.Size(33, 13);
            this.fromLabel.TabIndex = 1;
            this.fromLabel.Text = "From:";
            // 
            // toTextbox
            // 
            this.toTextbox.Location = new System.Drawing.Point(16, 66);
            this.toTextbox.Name = "toTextbox";
            this.toTextbox.Size = new System.Drawing.Size(100, 20);
            this.toTextbox.TabIndex = 2;
            // 
            // toLabel
            // 
            this.toLabel.AutoSize = true;
            this.toLabel.Location = new System.Drawing.Point(13, 50);
            this.toLabel.Name = "toLabel";
            this.toLabel.Size = new System.Drawing.Size(23, 13);
            this.toLabel.TabIndex = 3;
            this.toLabel.Text = "To:";
            // 
            // whileRadioButton
            // 
            this.whileRadioButton.AutoSize = true;
            this.whileRadioButton.Checked = true;
            this.whileRadioButton.Location = new System.Drawing.Point(21, 19);
            this.whileRadioButton.Name = "whileRadioButton";
            this.whileRadioButton.Size = new System.Drawing.Size(49, 17);
            this.whileRadioButton.TabIndex = 3;
            this.whileRadioButton.TabStop = true;
            this.whileRadioButton.Text = "while";
            this.whileRadioButton.UseVisualStyleBackColor = true;
            // 
            // loopUsingGroupBox
            // 
            this.loopUsingGroupBox.Controls.Add(this.dowhileRadioButton);
            this.loopUsingGroupBox.Controls.Add(this.forRadioButton);
            this.loopUsingGroupBox.Controls.Add(this.whileRadioButton);
            this.loopUsingGroupBox.Location = new System.Drawing.Point(16, 108);
            this.loopUsingGroupBox.Name = "loopUsingGroupBox";
            this.loopUsingGroupBox.Size = new System.Drawing.Size(104, 100);
            this.loopUsingGroupBox.TabIndex = 5;
            this.loopUsingGroupBox.TabStop = false;
            this.loopUsingGroupBox.Text = "Loop Using:";
            // 
            // dowhileRadioButton
            // 
            this.dowhileRadioButton.AutoSize = true;
            this.dowhileRadioButton.Location = new System.Drawing.Point(21, 65);
            this.dowhileRadioButton.Name = "dowhileRadioButton";
            this.dowhileRadioButton.Size = new System.Drawing.Size(64, 17);
            this.dowhileRadioButton.TabIndex = 5;
            this.dowhileRadioButton.Text = "do-while";
            this.dowhileRadioButton.UseVisualStyleBackColor = true;
            // 
            // forRadioButton
            // 
            this.forRadioButton.AutoSize = true;
            this.forRadioButton.Location = new System.Drawing.Point(21, 42);
            this.forRadioButton.Name = "forRadioButton";
            this.forRadioButton.Size = new System.Drawing.Size(37, 17);
            this.forRadioButton.TabIndex = 4;
            this.forRadioButton.Text = "for";
            this.forRadioButton.UseVisualStyleBackColor = true;
            // 
            // runButton
            // 
            this.runButton.Location = new System.Drawing.Point(26, 226);
            this.runButton.Name = "runButton";
            this.runButton.Size = new System.Drawing.Size(75, 23);
            this.runButton.TabIndex = 6;
            this.runButton.Text = "Run Loop";
            this.runButton.UseVisualStyleBackColor = true;
            this.runButton.Click += new System.EventHandler(this.runButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(26, 255);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 7;
            this.clearButton.Text = "Clear List";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // numbersListBox
            // 
            this.numbersListBox.FormattingEnabled = true;
            this.numbersListBox.Location = new System.Drawing.Point(152, 12);
            this.numbersListBox.Name = "numbersListBox";
            this.numbersListBox.Size = new System.Drawing.Size(120, 264);
            this.numbersListBox.TabIndex = 8;
            // 
            // Lab5Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 291);
            this.Controls.Add(this.numbersListBox);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.runButton);
            this.Controls.Add(this.loopUsingGroupBox);
            this.Controls.Add(this.toLabel);
            this.Controls.Add(this.toTextbox);
            this.Controls.Add(this.fromLabel);
            this.Controls.Add(this.fromTextBox);
            this.Name = "Lab5Form";
            this.Text = "Lab 5";
            this.loopUsingGroupBox.ResumeLayout(false);
            this.loopUsingGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox fromTextBox;
        private System.Windows.Forms.Label fromLabel;
        private System.Windows.Forms.TextBox toTextbox;
        private System.Windows.Forms.Label toLabel;
        private System.Windows.Forms.RadioButton whileRadioButton;
        private System.Windows.Forms.GroupBox loopUsingGroupBox;
        private System.Windows.Forms.RadioButton dowhileRadioButton;
        private System.Windows.Forms.RadioButton forRadioButton;
        private System.Windows.Forms.Button runButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.ListBox numbersListBox;
    }
}

