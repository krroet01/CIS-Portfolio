﻿// Grading ID: B1403
// Lab 5
// Due Date: Sunday, October 23, 2016 at 11:59 p.m.
// CIS 199-75
// This application allows a user to input ANY integer for the starting number and ending number and to increment the count with 
// a while loop, a for loop, and a do-while loop.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab5
{
    public partial class Lab5Form : Form
    {
        public Lab5Form()
        {
            InitializeComponent();
        }

        // Takes the fromNumber and toNumber and increments the count with each iteration listed.
        private void runButton_Click(object sender, EventArgs e)
        {
            int fromNumber; // Holds a starting point value
            int toNumber;   // Holds an ending point value
            int count = 1;  // Holds a counting value

            // Declare an integer for fromNumber and toNumber
            if (int.TryParse(fromTextBox.Text, out fromNumber))
            {
                if (int.TryParse(toTextbox.Text, out toNumber))
                {
                    if (fromNumber < toNumber)  // Makes sure the fromNumber is less than the toNumber
                    {
                        if (whileRadioButton.Checked) // The while radio button will run if checked
                        {
                            count = fromNumber; // Declares a starting point

                            while (count <= toNumber) // 
                            {
                                numbersListBox.Items.Add(count);
                                count++;
                            }
                        }
                        else if (forRadioButton.Checked) // The for radio button will run if checked
                        {
                            for (count = fromNumber; count <= toNumber; count++) // Declares a starting point and ending point
                            {
                                numbersListBox.Items.Add(count);
                            }
                        }
                        else // The do-while radio button will run if checked
                        {
                            count = fromNumber; // Declares a starting point

                            do // Do test will run first
                            {
                                numbersListBox.Items.Add(count);
                                count++;
                            }
                            while (count <= toNumber); // While test then runs
                        }
                    }
                    else
                    {
                        MessageBox.Show("Error: The 'from' number must be less than the 'to' number!"); // Error message will appear if fromNumber is less than toNumber
                    }
                }
                else
                {
                    MessageBox.Show("Error: Invalid 'to' number!"); // Error message will appear if anything other than an integer is inputted in the toNumber textbox
                }
            }
            else
            {
                MessageBox.Show("Error: Invalid 'from' number!"); // Error message will appear if anything other than an integer is inputted in the fromNumber
            }
        }

        // Clears the outputted numbers in the listbox
        private void clearButton_Click(object sender, EventArgs e)
        {
            numbersListBox.Items.Clear();
        }
    }
}
