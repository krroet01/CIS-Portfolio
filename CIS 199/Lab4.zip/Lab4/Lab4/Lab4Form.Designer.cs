﻿namespace Lab4
{
    partial class Lab4Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hsgpaTextBox = new System.Windows.Forms.TextBox();
            this.admissiontestscoreTextBox = new System.Windows.Forms.TextBox();
            this.hsgpaLabel = new System.Windows.Forms.Label();
            this.admissiontestscoreLabel = new System.Windows.Forms.Label();
            this.acceptrejectButton = new System.Windows.Forms.Button();
            this.acceptedLabel = new System.Windows.Forms.Label();
            this.rejectedLabel = new System.Windows.Forms.Label();
            this.acceptedOutputLabel = new System.Windows.Forms.Label();
            this.rejectedOutputLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // hsgpaTextBox
            // 
            this.hsgpaTextBox.Location = new System.Drawing.Point(140, 28);
            this.hsgpaTextBox.Name = "hsgpaTextBox";
            this.hsgpaTextBox.Size = new System.Drawing.Size(100, 20);
            this.hsgpaTextBox.TabIndex = 0;
            // 
            // admissiontestscoreTextBox
            // 
            this.admissiontestscoreTextBox.Location = new System.Drawing.Point(140, 66);
            this.admissiontestscoreTextBox.Name = "admissiontestscoreTextBox";
            this.admissiontestscoreTextBox.Size = new System.Drawing.Size(100, 20);
            this.admissiontestscoreTextBox.TabIndex = 1;
            // 
            // hsgpaLabel
            // 
            this.hsgpaLabel.AutoSize = true;
            this.hsgpaLabel.Location = new System.Drawing.Point(41, 31);
            this.hsgpaLabel.Name = "hsgpaLabel";
            this.hsgpaLabel.Size = new System.Drawing.Size(93, 13);
            this.hsgpaLabel.TabIndex = 2;
            this.hsgpaLabel.Text = "High School GPA:";
            // 
            // admissiontestscoreLabel
            // 
            this.admissiontestscoreLabel.AutoSize = true;
            this.admissiontestscoreLabel.Location = new System.Drawing.Point(22, 69);
            this.admissiontestscoreLabel.Name = "admissiontestscoreLabel";
            this.admissiontestscoreLabel.Size = new System.Drawing.Size(112, 13);
            this.admissiontestscoreLabel.TabIndex = 3;
            this.admissiontestscoreLabel.Text = "Admission Test Score:";
            // 
            // acceptrejectButton
            // 
            this.acceptrejectButton.Location = new System.Drawing.Point(44, 213);
            this.acceptrejectButton.Name = "acceptrejectButton";
            this.acceptrejectButton.Size = new System.Drawing.Size(102, 23);
            this.acceptrejectButton.TabIndex = 4;
            this.acceptrejectButton.Text = "Accept?/Reject?";
            this.acceptrejectButton.UseVisualStyleBackColor = true;
            this.acceptrejectButton.Click += new System.EventHandler(this.acceptrejectButton_Click);
            // 
            // acceptedLabel
            // 
            this.acceptedLabel.AutoSize = true;
            this.acceptedLabel.Location = new System.Drawing.Point(65, 135);
            this.acceptedLabel.Name = "acceptedLabel";
            this.acceptedLabel.Size = new System.Drawing.Size(56, 13);
            this.acceptedLabel.TabIndex = 5;
            this.acceptedLabel.Text = "Accepted:";
            // 
            // rejectedLabel
            // 
            this.rejectedLabel.AutoSize = true;
            this.rejectedLabel.Location = new System.Drawing.Point(68, 166);
            this.rejectedLabel.Name = "rejectedLabel";
            this.rejectedLabel.Size = new System.Drawing.Size(53, 13);
            this.rejectedLabel.TabIndex = 6;
            this.rejectedLabel.Text = "Rejected:";
            // 
            // acceptedOutputLabel
            // 
            this.acceptedOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.acceptedOutputLabel.Location = new System.Drawing.Point(127, 130);
            this.acceptedOutputLabel.Name = "acceptedOutputLabel";
            this.acceptedOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.acceptedOutputLabel.TabIndex = 7;
            this.acceptedOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rejectedOutputLabel
            // 
            this.rejectedOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rejectedOutputLabel.Location = new System.Drawing.Point(127, 161);
            this.rejectedOutputLabel.Name = "rejectedOutputLabel";
            this.rejectedOutputLabel.Size = new System.Drawing.Size(100, 23);
            this.rejectedOutputLabel.TabIndex = 8;
            this.rejectedOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(165, 213);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 5;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.rejectedOutputLabel);
            this.Controls.Add(this.acceptedOutputLabel);
            this.Controls.Add(this.rejectedLabel);
            this.Controls.Add(this.acceptedLabel);
            this.Controls.Add(this.acceptrejectButton);
            this.Controls.Add(this.admissiontestscoreLabel);
            this.Controls.Add(this.hsgpaLabel);
            this.Controls.Add(this.admissiontestscoreTextBox);
            this.Controls.Add(this.hsgpaTextBox);
            this.Name = "Form4";
            this.Text = "Lab4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox hsgpaTextBox;
        private System.Windows.Forms.TextBox admissiontestscoreTextBox;
        private System.Windows.Forms.Label hsgpaLabel;
        private System.Windows.Forms.Label admissiontestscoreLabel;
        private System.Windows.Forms.Button acceptrejectButton;
        private System.Windows.Forms.Label acceptedLabel;
        private System.Windows.Forms.Label rejectedLabel;
        private System.Windows.Forms.Label acceptedOutputLabel;
        private System.Windows.Forms.Label rejectedOutputLabel;
        private System.Windows.Forms.Button clearButton;
    }
}

