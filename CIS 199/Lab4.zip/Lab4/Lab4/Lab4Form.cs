﻿// Grading ID: B1403
// Lab 4
// Due Date: October 2, 2016 at 11:59 PM
// CIS 199-75
// This applications allows the user to enter their high school GPA and admission test score and see if they quality for
// acception.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Lab4Form : Form
    {
        const decimal GPA_REQUIREMENT = 3.0m;           // A constant rate of a 3.0 GPA
        const int MINIMUMTESTSCORE_REQUIREMENTONE = 60; // A constant rate of a 60% test score if GPA is at least a 3.0
        const int MINIMUMTESTSCORE_REQUIREMENTTWO = 80; // A constant rate of an 80% test score if GPA is less than a 3.0

        int TOTALACCEPTED = 0;  // Holds the running total for students accepted
        int TOTALREJECTED = 0;  // Holds the running total for students rejected

        public Lab4Form()
        {
            InitializeComponent();
        }

        // Calculates the student's eligibility based on their high school GPA and admission test score
        private void acceptrejectButton_Click(object sender, EventArgs e)
        {
            decimal hsGPA;          // Holds the student's given high school GPA
            int admissionTestScore; // Holds the student's given admission test score
            int accepted;           // Holds the number of students that have been accepted
            int rejected;           // Holds the number of students that have been rejected
            
            accepted = 1;   // Adds to the running total when accept occurs
            rejected = 1;   // Adds to the running total when reject occurs

            // Determines the student's acception or rejection
            if (decimal.TryParse(hsgpaTextBox.Text, out hsGPA))
            {
                if (int.TryParse(admissiontestscoreTextBox.Text, out admissionTestScore))
                {
                    if (hsGPA >= GPA_REQUIREMENT)
                    {
                        if (admissionTestScore >= MINIMUMTESTSCORE_REQUIREMENTONE)
                        {
                            MessageBox.Show("Accept");
                            TOTALACCEPTED += accepted;
                            acceptedOutputLabel.Text = TOTALACCEPTED.ToString("n0");
                        }
                        else
                        {
                            MessageBox.Show("Reject");
                            TOTALREJECTED += rejected;
                            rejectedOutputLabel.Text = TOTALREJECTED.ToString("n0");
                        }
                    }
                    else
                    {
                        if (admissionTestScore >= MINIMUMTESTSCORE_REQUIREMENTTWO)
                        {
                            MessageBox.Show("Accept");
                            TOTALACCEPTED += accepted;
                            acceptedOutputLabel.Text = TOTALACCEPTED.ToString("n0");
                        }
                        else
                        {
                            MessageBox.Show("Reject");
                            TOTALREJECTED += rejected;
                            rejectedOutputLabel.Text = TOTALREJECTED.ToString("n0");
                        }
                    }
                }
            }
        }

        // Clears the input in the high school GPA and admission test score textboxes
        private void clearButton_Click(object sender, EventArgs e)
        {
            hsgpaTextBox.Text = "";
            admissiontestscoreTextBox.Text = "";
        }
    }
}
