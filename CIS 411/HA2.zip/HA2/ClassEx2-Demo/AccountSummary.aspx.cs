﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassEx2_Demo.MyClasses;

namespace ClassEx2_Demo
{
    public partial class AccountSummary : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Create the objects and set them in the session
            GenerateSessionObjects sessionObjs = new GenerateSessionObjects();

            //Retrieve the objects from the session
            List<Account> acctList = (List<Account>)Session["AllAccounts"];

            //Populate the label and the listbox
            Customer cust = (Customer)Session["customer"];

            NameLabel.Text = "Welcome " + cust.FullName;

            Session.Add("LoanApplication", AccountListBox.SelectedIndex);
            
            foreach(Account acct in acctList)
            {
                AccountListBox.Items.Add(acct.Nickname);
            }

        }

        protected void DetailsButton_Click(object sender, EventArgs e)
        {
            Server.Transfer("AccountPages/AccountDetails.aspx");
        }
    }
}