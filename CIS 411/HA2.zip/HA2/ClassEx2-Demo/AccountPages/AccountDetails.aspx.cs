﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassEx2_Demo.MyClasses;

namespace ClassEx2_Demo.AccountPages
{
    public partial class AccountDetails : System.Web.UI.Page
    {
        List<Account> allAccounts => (List<Account>)Session["AllAccounts"];
        Customer cust => (Customer)Session["customer"];

        Account selectedAccount => allAccounts[(int)Session["LoanApplication"]];

        protected void Page_LoadComplete(object sender, EventArgs e)
        {
            AccountNameLabel.Text = selectedAccount.Nickname;
            AccountTypeLabel.Text = selectedAccount.Type;
            AccountBalanceLabel.Text = selectedAccount.Balance.ToString();
            LoanLabel.Text = selectedAccount.hasLoanOffer().ToString();
            AddressLabel.Text = cust.FullAddress;
        }

        protected void WithdrawButton_Click(object sender, EventArgs e)
        {
            double withdrawAmount = double.Parse(WithdrawTextBox.Text);
            double balanceAmount = double.Parse(AccountBalanceLabel.Text);
            double updatedBalance = balanceAmount - withdrawAmount;

            if (withdrawAmount < balanceAmount)
            {
                selectedAccount.Balance = updatedBalance;
            }
            else
            {
                WithdrawErrorLabel.Text = "Withdrawal Amount is greater than Balance";
            }
            
        }
    }
}