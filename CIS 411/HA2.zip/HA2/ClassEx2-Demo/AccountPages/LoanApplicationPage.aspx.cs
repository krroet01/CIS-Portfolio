﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ClassEx2_Demo.MyClasses;
using ClassEx2_Demo.AccountPages;

namespace ClassEx2_Demo.AccountPages
{
    public partial class LoanApplicationPage : System.Web.UI.Page
    {
        Account selectedAccount;

        protected void Page_Load(object sender, EventArgs e)
        {
            List<Account> allAccounts = (List<Account>)Session["AllAccounts"];
            Customer cust = (Customer)Session["customer"];

            //Find the details of the account that was selected
            selectedAccount = allAccounts[(int)Session["LoanApplication"]];

            NameLabel.Text = cust.FullName;
        }

        protected void SubmitButton_Click(object sender, EventArgs e)
        {
            double age = double.Parse(AgeTextBox.Text);
            double loan = double.Parse(LoanAmountTextBox.Text);
            double salary = double.Parse(SalaryTextBox.Text);
            
            if (age > 18 && loan < selectedAccount.Balance && loan < 0.5*salary)
            {
                LoanApprovalLabel.Text = "Congratulations!! Your loan is approved.";
            }
            else
            {
                LoanApprovalLabel.Text = "Your loan is not approved. Sorry!!";
            }
            
        }

     
    }
}