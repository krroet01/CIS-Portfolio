﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Question_2
{
    public partial class Question_2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            if (!IsPostBack)
            {
                BookDropDownList.Items.Add("Introduction to MIS");
                BookDropDownList.Items.Add("Introduction to Marketing");
                BookDropDownList.Items.Add("Introduction to Finance");
            }
        }

        protected void PurchaseButton_Click(object sender, EventArgs e)
        {
            MessageLabel.Text = "You have selected " + QuantityTextBox.Text + " number of " + BookDropDownList.SelectedItem.Text;
        }
    }
}
