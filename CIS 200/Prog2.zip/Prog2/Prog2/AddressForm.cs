﻿// Grading ID: C6221
// Program 2
// Due: 10/23/17 @ 11:59 pm
// CIS 200-01
// Description: This AddressForm class is a form used to enter address information when the Address Item under the 
//              Insert menu is selected. 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class AddressForm : Form
    {
        // Precondition: None
        // Postcondition: The Address Form GUI is initialized
        public AddressForm()
        {
            InitializeComponent();
        }

        public String Name
        {
            // Precondition: None
            // Postcondition: Name is returned 
            get
            {
                return nameTextBox.Text;
            }
            // Precondition: None
            // Postcondition: Name is set to the specified value
            set
            {
                nameTextBox.Text = value;
            }
        }

        public String AddressLine1
        {
            // Precondition: None
            // Postcondition: Address Line 1 is returned 
            get
            {
                return address1TextBox.Text;
            }
            // Precondition: None
            // Postcondition: Address Line 1 is set to the specified value
            set
            {
                address1TextBox.Text = value;
            }
        }

        public String AddressLine2
        {
            // Precondition: None
            // Postcondition: Address Line 2 is returned 
            get
            {
                return address2TextBox.Text;
            }
            // Precondition: None
            // Postcondition: Address Line 2 is set to the specified value
            set
            {
                address2TextBox.Text = value;
            }
        }

        public String City
        {
            // Precondition: None
            // Postcondition: City is returned 
            get
            {
                return cityTextBox.Text;
            }
            // Precondition: None
            // Postcondition: City is set to the specified value
            set
            {
                cityTextBox.Text = value;
            }
        }

        public int StateIndex
        {
            // Precondition: None
            // Postcondition: State combo box index is returned 
            get
            {
                return stateComboBox.SelectedIndex;
            }
        }

        public String Zip
        {
            // Precondition: None
            // Postcondition: Zipcode is returned 
            get
            {
                return zipcodeTextBox.Text;
            }
            // Precondition: None
            // Postcondition: Zipcode is set to the specified value
            set
            {
                zipcodeTextBox.Text = value;
            }
        }

        // Precondition: Focus is shifting from nameTextBox
        // Postcondition: If text is invalid, focus remains and error provider highlights the field
        private void nameTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (nameTextBox.TextLength == 0)
            {
                e.Cancel = true;    // stops focus changing process, will not proceed to validated event
                errorProvider1.SetError(nameTextBox, "Must provide name");  // sets error message
            }
        }

        // Preconditions: Validating of nameText succeeded
        // Postconditions: Error provider cleared and focus allowed to change
        private void nameTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(nameTextBox, "");   // clears error message
        }

        // Precondition: Focus is shifting from address1TextBox
        // Postcondition: If text is invalid, focus remains and error provider highlights the field
        private void address1TextBox_Validating(object sender, CancelEventArgs e)
        {
            if (address1TextBox.TextLength == 0)
            {
                e.Cancel = true;    // stops focus changing process, will not proceed to validated event
                errorProvider1.SetError(address1TextBox, "Must provide address"); // sets error message
            }
        }

        // Precondition: Validating of address1Text succeeded
        // Postcondition: Error provider cleared and focus allowed to change
        private void address1TextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(address1TextBox, "");   // clears error message
        }

        // Precondition:  Focus is shifting from cityTextBox
        // Postcondition: If text is invalid, focus remains and error provider highlights the field
        private void cityTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (cityTextBox.TextLength == 0)
            {
                e.Cancel = true;    // stops focus changing process, will not proceed to validated event
                errorProvider1.SetError(cityTextBox, "Must provide city");  // sets error message
            }
        }

        // Precondition: Validating of cityText succeeded
        // Postcondition: Error provider cleared and focus allowed to change
        private void cityTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(cityTextBox, "");   // clears error message
        }

        // Precondition: Focus is shifting from stateComboBox 
        // Postcondition: If text is invalid, focus remains and error provider highlights the field
        private void stateComboBox_Validating(object sender, CancelEventArgs e)
        {
            if (stateComboBox.SelectedIndex == -1)
                e.Cancel = true;    // stops focus changing process, will not proceed to validated event
            errorProvider1.SetError(stateComboBox, "Must select state");    // sets error message
        }

        // Precondition: Validating of stateComboBox succeeded
        // Postcondition: Error provider cleared and focus allowed to change
        private void stateComboBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(stateComboBox, ""); // clears error message
        }

        // Precondition: Focus is shifting from zipcodeTextBox
        // Postcondition: If text is invalid, focus remains and error provider highlights the field
        private void zipcodeTextBox_Validating(object sender, CancelEventArgs e)
        {
            int zipcode;            // Value entered into zipcode textbox
            bool valid = true;      // Tests zipcode validity

            // Trying to parse as int, if fails, TryParse returns false 
            // If zipcode is less than 0, TryParse returns false
            // If succeeds and zipcode is valid, TryParse returns true and zipcode stores parsed value. 
            if (!int.TryParse(zipcodeTextBox.Text, out zipcode))
                valid = false;
            else if (zipcode < 0)
                valid = false;

            if (!valid)
            {
                e.Cancel = true;    // stops focus changing process, will not proceed to validated event
                zipcodeTextBox.SelectAll(); // select all text in zipcode textbox to ease correction
                errorProvider1.SetError(zipcodeTextBox, "Invalid zip code");    // sets error message
            }
        }

        // Precondition: Validating of zipText succeeded
        // Postcondition: Error provider cleared and focus allowed to change
        private void zipcodeTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(zipcodeTextBox, "");    // clears error message
        }

        // Precondition: Ok is clicked
        // Postcondition: Address is added
        private void okButton_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }

        // Precondition: Cancel is clicked 
        // Postcondition: Address form is closed 
        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;    
        }
    }
}
