﻿// Grading ID: C6221
// Program 2
// Due: 10/23/17 @ 11:59 pm
// CIS 200-01
// Description: This is a GUI Parcel program that serves as a front end for application UserParcelView
using Prog2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class Prog2Form : Form
    {
        private UserParcelView upv;     

        // Precondition: None
        // Postcondition: The Program 2 Form GUI is initialized
        public Prog2Form()
        {
            InitializeComponent();

            upv = new UserParcelView();
        }

        // Precondition: About menu item is clicked
        // Postcondition: Message box appears showing descriptions of program 2
        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Grading ID: C6221" + Environment.NewLine + "Program 2" + Environment.NewLine + "CIS 200-01");
        }
        
        // Precondition: Exit menu item is clicked
        // Postcondition: Form is closed 
        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Precondition: Insert address is clicked
        // Postcondition: Address is created
        private void addressToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            AddressForm addressForm = new AddressForm();    // dialog box form

            DialogResult result = addressForm.ShowDialog(); // show result from dialog - OK/Cancel?

            if (result == DialogResult.OK)  // only update is user chooses OK from dialog box
            {
                // retrieve value(s) from dialog box
                upv.AddAddress(addressForm.Name, addressForm.AddressLine1, addressForm.AddressLine2, 
                    addressForm.City, addressForm.StateIndex.ToString(), int.Parse(addressForm.Zip));

                // Address Test objects
                upv.AddAddress("John Smith", "123 Any St.", "Apt. 45", "Louisville", "KY", 40202);
                upv.AddAddress("Jane Doe", "987 Main St.", "Beverly Hills", "CA", 90210);
                upv.AddAddress("James Kirk", "654 Roddenberry Way", "Suite 321", "El Paso", "TX", 79901);
                upv.AddAddress("John Crichton", "678 Pau Place", "Apt. 7", "Portland", "ME", 04101);
                upv.AddAddress("David White", "62 Twin Willow Lane", "West Bridgewater", "MA", 02379);
                upv.AddAddress("Regina Phalange", "5 Morton Street", "Apt. 14", "New York City", "NY", 10005);
                upv.AddAddress("Ken Adams", "90 Bedford Street", "Apt. 19", "New York City", "NY", 10009);
                upv.AddAddress("Maria Briggs", "4949 Meadowcrest Lane", "Branchville", "SC", 29432);
            }

            addressForm.Dispose();
        }

        // Precondition: Insert Letter is clicked
        // Postcondition: Letter is clicked
        private void letterToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            LetterForm letterform = new LetterForm();   // dialog box form

            letterform.Addresses = upv.AddressList;     // pulls list of addresses

            DialogResult result = letterform.ShowDialog();  // show result from dialog - OK/Cancel?

            string originAddress;       // string variable to hold the origin address
            string destinationAddress;  // string variable to hold the destination address

            if (result == DialogResult.OK)  // only update if user chooses OK from dialog box
            {
                // retrieve values from dialog box
                originAddress = letterform.originIndex.ToString();
                destinationAddress = letterform.destinationIndex.ToString();

                Address oAddress = upv.AddressAt(int.Parse(originAddress));
                Address dAddress = upv.AddressAt(int.Parse(destinationAddress));
 
                // Parcel test objects
                upv.AddLetter(oAddress, dAddress, 3.95M);
                upv.AddLetter(oAddress, dAddress, 9.10M);
                upv.AddGroundPackage(oAddress, dAddress, 14, 10, 5, 12.5);
                upv.AddGroundPackage(oAddress, dAddress, 25, 16, 3, 17.5);
                upv.AddNextDayAirPackage(oAddress, dAddress, 25, 15, 15, 85, 7.50M);
                upv.AddNextDayAirPackage(oAddress, dAddress, 36, 34, 12, 93, 4.20M);
                upv.AddTwoDayAirPackage(oAddress, dAddress, 46.5, 39.5, 28.0, 80.5, TwoDayAirPackage.Delivery.Saver);
                upv.AddTwoDayAirPackage(oAddress, dAddress, 67.5, 48.5, 16.0, 78.5, TwoDayAirPackage.Delivery.Early);

            }

            letterform.Dispose();
        }

        // Precondition: Report List Addresses is clicked
        // Postcondition: Form shows list of addresses
        private void listAddressesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            StringBuilder result = new StringBuilder(); // dialog box form

            foreach (Address address in upv.addresses)
            {
                result.Append(address.ToString());
                result.Append(Environment.NewLine);
                result.Append(Environment.NewLine);
            }

            reportTextBox.Text = result.ToString();     // show result
            reportTextBox.SelectionStart = 0;
        }

        // Precondition: Report List Parcels is clicked
        // Postcondition: Form shows list of parcels
        private void listParcelsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            StringBuilder result = new StringBuilder(); // dialog box form

            foreach (Parcel parcel in upv.parcels)
            {
                result.Append(parcel.ToString());
                result.Append(Environment.NewLine);
                result.Append(Environment.NewLine);
            }

            reportTextBox.Text = result.ToString();     // show result
            reportTextBox.SelectionStart = 0;
        }
    }
}
