﻿// Grading ID: C6221
// Program 2
// Due: 10/23/17 @ 11:59 pm
// CIS 200-01
// Description: This LetterForm class is a form used to enter letter information when the Letter item under the 
//              Insert menu is selected. 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prog2
{
    public partial class LetterForm : Form
    {
        public List<Address> Addresses; // List of addresses stored for this user

        // Precondition: None
        // Postcondition: The Letter Form GUI is initialized
        public LetterForm()
        {
            InitializeComponent();
        }

        // Precondition: Form is loaded
        // Postcondition: Combo boxes are populated 
        private void LetterForm_Load(object sender, EventArgs e)
        {
            foreach (Address address in Addresses)
                originAddressComboBox.Items.Add(address.Name);  // Name property as string listed in combo box

            foreach (Address address in Addresses)
                destinationAddressComboBox.Items.Add(address.Name); // Name property as string listed in combo box
        }

        public int originIndex
        {
            // Precondition: None
            // Postcondition: Origin address combo box index is returned 
            get
            {
                return originAddressComboBox.SelectedIndex;
            }
        }

        public int destinationIndex
        {
            // Precondition: None
            // Postcondition: Destination address combo box index is returned 
            get
            {
                return destinationAddressComboBox.SelectedIndex;
            }
        }

        // Precondition: Focus is shifting from originAddressComboBox
        // Postcondition: If text is invalid, focus remains and error provider highlights the field
        private void originAddressComboBox_Validating(object sender, CancelEventArgs e)
        {
            if (originAddressComboBox.SelectedIndex == -1)
            {
                e.Cancel = true;    // stops focus changing process, will not proceed to validated event
                errorProvider1.SetError(originAddressComboBox, "Must select origin address");   // sets error message
            }
        }

        // Precondition: Validating of originAddressComboBox succeeded
        // Postcondition: Error provider cleared and focus allowed to change
        private void originAddressComboBox_Validated(object sender, CancelEventArgs e)
        {
            errorProvider1.SetError(originAddressComboBox, "");     // clears error message
        }

        // Precondition: Focus is shifting from destinationAddressComboBox
        // Postcondition: If text is invalid, focus remains and error provider highlights the field
        private void destinationAddressComboBox_Validating(object sender, CancelEventArgs e)
        {
            if (destinationAddressComboBox.SelectedIndex == -1)
            {
                e.Cancel = true;    // stops focus changing process, will not proceed to validated event
                errorProvider1.SetError(destinationAddressComboBox, "Must select destination address"); // sets error message
                
            }
        }

        // Precondition: Validating of destinationAddressComboBox succeeded
        // Postcondition: Error provider cleared and focus allowed to change
        private void destinationAddressComboBox_Validated(object sender, CancelEventArgs e)
        {
            errorProvider1.SetError(destinationAddressComboBox, "");    // clears error message
        }

        // Precondition: Ok is clicked 
        // Postcondition: Letter is added
        private void okButton_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }

        // Precondition: Cancel is clicked
        // Postcondition: Letter form is closed
        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
