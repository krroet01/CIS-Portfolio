﻿// Grading ID: C6221
// Program 4 
// Due: Monday 11/27/2017 at 11:59 pm
// CIS 200-01

// File: ExtraCredit.cs
// This class is designed to implement the IComparer interface to create a new sort order that will first order by Parcel type (ascending) and then cost (descending) within each grouping

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class ExtraCredit : IComparer<Parcel>
    {
        // Precondition: None
        // Postcondition: When x < y, method returns negative number
        //                When x = y, method returns zero
        //                When x > y, method returns positive number 
        public int Compare(Parcel x, Parcel y)
        {
            string parcelType1;     // variable to hold x's type
            string parcelType2;     // variable to hold y's type

            if (x == null && y == null)
                return 0;

            if (x == null)
                return -1;

            if (y == null)
                return 1;

            parcelType1 = x.GetType().ToString();
            parcelType2 = y.GetType().ToString();

            if (parcelType1 == parcelType2)
                return (x.CalcCost()).CompareTo(y.CalcCost());

            return parcelType1.CompareTo(parcelType2);
        }
    }
}
