﻿// Grading ID: C6221
// Program 4 
// Due: Monday 11/27/2017 at 11:59 pm
// CIS 200-01

// File: DescOrderByZip.cs
// This class is designed to implement the IComparer interface and allow parcels to be put in descending order by destination zip code

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class DescOrderByZip : IComparer<Parcel>
    {
        // Precondition: None
        // Postcondition: When x < y, method returns negative number
        //                When x = y, method returns zero
        //                When x > y, method returns positive number
        public int Compare(Parcel x, Parcel y)
        {
            if (x == null && y == null)
                return 0;

            if (x == null)
                return -1;

            if (y == null)
                return 1;

            return (y.DestinationAddress.Zip).CompareTo(x.DestinationAddress.Zip);
        }
    }
}
