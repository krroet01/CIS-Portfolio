﻿// Kimberly Roeten, Grading ID: C6221
// Program 1B
// Due: 10/4/2017 @ 11:59 pm
// CIS 200-01

// File: TestParcels.cs
// This is a simple, console application designed to exercise the Parcel hierarchy.
// It creates several different Parcels and prints them.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class TestParcels
    {
        // Precondition:  None
        // Postcondition: Parcels have been created and displayed
        static void Main(string[] args)
        {
            // Test Data - Magic Numbers OK
            Address a1 = new Address("  John Smith  ", "   123 Any St.   ", "  Apt. 45 ",
                "  Louisville   ", "  KY   ", 40202); // Test Address 1
            Address a2 = new Address("Jane Doe", "987 Main St.",
                "Beverly Hills", "CA", 90210); // Test Address 2
            Address a3 = new Address("James Kirk", "654 Roddenberry Way", "Suite 321",
                "El Paso", "TX", 79901); // Test Address 3
            Address a4 = new Address("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 04101); // Test Address 4
            Address a5 = new Address("David White", "62 Twin Willow Lane",
                "West Bridgewater", "MA", 02379); // Test Address 5
            Address a6 = new Address("Regina Phalange", "5 Morton Street", "Apt. 14",
                "New York City", "NY", 10005); // Test Address 6
            Address a7 = new Address("Ken Adams", "90 Bedford Street", "Apt. 19",
                "New York City", "NY", 10009); // Test Address 7
            Address a8 = new Address("Maria Briggs", "4949 Meadowcrest Lane", 
                "Branchville", "SC", 29432); // Test Address 8

            Letter letter1 = new Letter(a1, a2, 3.95M);                                         // Letter test object
            Letter letter2 = new Letter(a6, a7, 9.10M);                                         // Letter test object
            GroundPackage gp1 = new GroundPackage(a3, a4, 14, 10, 5, 12.5);                     // Ground Package test object
            GroundPackage gp2 = new GroundPackage(a5, a8, 25, 16, 3, 17.5);                     // Ground Package test object
            NextDayAirPackage ndap1 = new NextDayAirPackage(a1, a3, 25, 15, 15, 85, 7.50M);     // Next Day test object
            NextDayAirPackage ndap2 = new NextDayAirPackage(a6, a8, 36, 34, 12, 93, 4.20M);     // Next Day test object 
            TwoDayAirPackage tdap1 = new TwoDayAirPackage(a4, a1, 46.5, 39.5, 28.0,             // Two Day test object
                80.5, TwoDayAirPackage.Delivery.Saver);
            TwoDayAirPackage tdap2 = new TwoDayAirPackage(a5, a6, 67.5, 48.5, 16.0,             // Two Day test object 
                78.5, TwoDayAirPackage.Delivery.Early);

            List<Parcel> parcels = new List<Parcel>(); // List of test parcels

            // Populate list
            parcels.Add(letter1); 
            parcels.Add(gp1);
            parcels.Add(ndap1);
            parcels.Add(tdap1);
            parcels.Add(letter2);
            parcels.Add(gp2);
            parcels.Add(ndap2);
            parcels.Add(tdap2);

            Console.WriteLine("Original List:");
            Console.WriteLine("====================");
            foreach (Parcel p in parcels)
            {
                Console.WriteLine(p);
            }

            // Part A
            // Use LINQ (TestParcels) to sort the parcels by destination address zipcode in descending order
            var PartA =
                from p in parcels
                orderby p.DestinationAddress.Zip descending
                select p;

            // Display the parcels
            Console.WriteLine("\nPart A:");
            Console.WriteLine("===============================================================================");
            foreach (var element in PartA)
            {
                Console.WriteLine(element);
            }

            // Part B
            // Use LINQ (TestParcels) to sort the parcels by cost in ascending order
            var PartB =
                from p in parcels
                orderby p.CalcCost() ascending
                select p;

            // Display the parcels
            Console.WriteLine("\nPart B:");
            Console.WriteLine("===============================================================================");
            foreach (var element in PartB)
            {
                Console.WriteLine(element);
            }

            // Part C
            // Use LINQ (TestParcels) to sort the parcels by type in ascending order then cost in descending order
            var PartC =
                from p in parcels
                orderby p.GetType().ToString() ascending, p.CalcCost() descending
                select p;

            // Display the parcels
            Console.WriteLine("\nPart C:");
            Console.WriteLine("===============================================================================");
            foreach (var element in PartC)
            {
                Console.WriteLine(element.GetType().ToString());
                Console.WriteLine("    " + element.CalcCost());
            }

            // Part D
            // Use LINQ (TestParcels) to sort the heavy AirPackage objects by weight in descending order
            var PartD =
                from p in parcels
                let AP = p as AirPackage
                where AP != null && AP.IsHeavy()
                orderby AP.Weight descending
                select AP;

            // Display the parcels
            Console.WriteLine("\nPart D:");
            Console.WriteLine("===============================================================================");
            foreach (var element in PartD)
            {
                Console.WriteLine(element);
            }

            Pause();
       }

        // Precondition:  None
        // Postcondition: Pauses program execution until user presses Enter and
        //                then clears the screen
        public static void Pause()
        {
            Console.WriteLine("Press Enter to Continue...");
            Console.ReadLine();

            Console.Clear(); // Clear screen
        }
    }
}
