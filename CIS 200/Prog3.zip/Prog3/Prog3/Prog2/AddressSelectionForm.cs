﻿// Grading ID: C6221
// Program 3
// CIS 200-01
// Due: 11/13/2017

// File: AddressSelectionForm.cs
// This class lets a user edit an address. It performs validation
// and provides properties properties for each field.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class AddressSelectionForm : Form
    {
        public const int MIN_ADDRESS = 1; // Minimum number of addresses needed

        private List<Address> addressList; // List of addresses used to fill combo box

        // Precondition:  addresses.Count >= MIN_ADDRESSES
        // Postcondition: The form's GUI is prepared for display.
        public AddressSelectionForm(List<Address> addresses)
        {
            InitializeComponent();
            addressList = addresses;
        }

        internal int AddressIndex
        {
            // Precondition:  User has selected from originAddCbo
            // Postcondition: The index of the selected origin address returned
            get
            {
                return selectAddressComboBox.SelectedIndex;
            }

            // Precondition:  -1 <= value < addressList.Count
            // Postcondition: The specified index is selected in originAddCbo
            set
            {
                if ((value >= -1) && (value < addressList.Count))
                    selectAddressComboBox.SelectedIndex = value;
                else
                    throw new ArgumentOutOfRangeException("AddressIndex", value,
                        "Index must be valid");
            }
        }

        // Precondition:  addressList.Count >= MIN_ADDRESSES
        // Postcondition: The list of addresses is used to populate the
        //                origin and destination address combo boxes
        private void AddressSelectionForm_Load(object sender, EventArgs e)
        {
            if (addressList.Count < MIN_ADDRESS) // Violated precondition!
            {
                MessageBox.Show("Need " + MIN_ADDRESS + " addresses to create letter!",
                    "Addresses Error");
                this.DialogResult = DialogResult.Abort; // Dismiss immediately
            }
            else
            {
                foreach (Address a in addressList)
                {
                    selectAddressComboBox.Items.Add(a.Name);
                }
            }
        }

        // Precondition: Focus is shifted from the address combo box
        // Postcondition: If selection is invalid, focus remains and error provider
        //                 highlights the field
        private void selectAddressComboBox_Validating(object sender, CancelEventArgs e)
        {
            if (selectAddressComboBox.SelectedIndex == -1) // Nothing selected
            {
                e.Cancel = true;
                errorProvider1.SetError(selectAddressComboBox, "Must select Address");
            }
        }

        // Precondition: Validating of address combobox not cancelled, so data OK
        // Postcondition: Error provider cleared and focus allowed to change
        private void selectAddressComboBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(selectAddressComboBox, "");
        }

        // Precondition:  Validating of sender not cancelled, so data OK
        //                sender is Control
        // Postcondition: Error provider cleared and focus allowed to change
        private void AllFields_Validated(object sender, EventArgs e)
        {
            // Downcast to sender as Control, so make sure you obey precondition!
            Control control = sender as Control; // Cast sender as Control
                                                 // Should always be a Control
            errorProvider1.SetError(control, "");
        }

        // Precondition:  User clicked on okBtn
        // Postcondition: If invalid field on dialog, keep form open and give first invalid
        //                field the focus. Else return OK and close form.
        private void okButton_Click(object sender, EventArgs e)
        {
            if (ValidateChildren())
                this.DialogResult = DialogResult.OK;
        }

        // Precondition:  User pressed on cancelBtn
        // Postcondition: Form closes
        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
